import {Easing, interpolate, random} from 'remotion';

// Keyframe track: kf(frame, [[f0, v0], [f1, v1], ...]) with smooth easing between keys.
export const kf = (f: number, keys: [number, number][]) => {
  if (keys.length === 1) return keys[0][1];
  return interpolate(f, keys.map((k) => k[0]), keys.map((k) => k[1]), {
    easing: Easing.inOut(Easing.cubic), extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
};

// Smooth value noise in 0..1
export const noise = (seed: string, f: number, speed = 0.15) => {
  const i = Math.floor(f * speed), t = f * speed - i;
  const a = random(seed + i), b = random(seed + (i + 1));
  return a + (b - a) * (t * t * (3 - 2 * t));
};

// Blink amount 0..1 from a list of blink start frames (6-frame blink)
export const blinkAt = (f: number, blinks: number[]) => {
  let c = 0;
  for (const b of blinks) {
    const d = f - b;
    if (d >= 0 && d < 7) c = Math.max(c, d < 3 ? d / 2.5 : Math.max(0, (6 - d) / 3));
  }
  return Math.min(1, c);
};

// Mouth openness 0..1 while speaking. segs = [start, end] of each spoken phrase.
// Until the real voice track is in, syllables are faked with a rhythmic pattern.
export const talkOpen = (f: number, segs: [number, number][], seed = 'talk') => {
  for (const [s, e] of segs) {
    if (f >= s && f <= e) {
      const fade = Math.min(1, (f - s) / 3, (e - f) / 3);
      const syll = Math.abs(Math.sin((f - s) * 0.55 + random(seed + s) * 3));
      return Math.max(0, syll * (0.55 + 0.45 * noise(seed, f, 0.3)) * fade);
    }
  }
  return 0;
};
