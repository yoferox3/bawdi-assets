# Soundtrack from real sound effects (Pixabay, free licence) + the voices.
# Needs: sfx/<name>.mp3 (see sfx_list.txt), work/voice.f32, remotion/src/timeline.json
# Output: work/mix.wav (44.1 kHz stereo)
import json, numpy as np, subprocess
SR = 44100
T = json.load(open('remotion/src/timeline.json'))
N = int((T['total'] + 1) * SR)
voice = np.fromfile('work/voice.f32', np.float32)[:N]; voice = np.pad(voice, (0, N - len(voice)))
amb = np.zeros(N, np.float32); fx = np.zeros(N, np.float32); mus = np.zeros(N, np.float32)
SC = {s['id']: s for s in T['scenes']}; LN = {}
for l in T['lines']: LN.setdefault(l['scene'], []).append(l)
def at(sid, k=None, off=0.0): return (LN[sid][k]['start'] if k is not None else SC[sid]['start']) + off
def span(sid): return SC[sid]['start'], SC[sid]['end']

_cache = {}
def S(name):
    if name not in _cache:
        a = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', f'sfx/{name}.mp3', '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'],
                                         capture_output=True).stdout, np.float32).copy()
        m = np.abs(a).max(); _cache[name] = a / m if m > 0 else a
    return _cache[name]
def fade(x, a=0.05, b=0.3):
    x = x.copy(); na, nb = min(len(x), int(a * SR)), min(len(x), int(b * SR))
    if na: x[:na] *= np.linspace(0, 1, na)
    if nb: x[-nb:] *= np.linspace(1, 0, nb)
    return x
def put(buf, t, name, g=1.0, dur=None, skip=0.0, fin=0.02, fout=0.2):
    a = S(name)[int(skip * SR):]
    if dur: a = a[:int(dur * SR)]
    a = fade(a, fin, fout); s = int(t * SR); e = min(N, s + len(a))
    if 0 <= s < N: buf[s:e] += a[:e - s] * g
def loop(buf, t0, t1, name, g=0.3, xf=1.0):
    a = S(name); n = int((t1 - t0) * SR); out = np.zeros(n, np.float32); pos = 0; L = len(a); x = int(xf * SR)
    while pos < n:
        seg = a.copy()
        if pos > 0: seg[:x] *= np.linspace(0, 1, x)
        seg[-x:] *= np.linspace(1, 0, x)
        e = min(n, pos + L); out[pos:e] += seg[:e - pos]; pos += L - x
    out = fade(out, 1.5, 1.5); s = int(t0 * SR); buf[s:s + n] += out[:N - s] * g
def steps(buf, t0, t1, name='steps', g=0.35):
    loop(buf, t0, t1, name, g, 0.3)

# ---------- scene by scene ----------
s, e = span('s01_coldopen'); loop(amb, s, e, 'amb3', 0.45); loop(amb, s, e, 'wind', 0.2); loop(amb, s + 2, e - 3, 'drip2', 0.35)
put(fx, at('s01_coldopen', 4) - 0.3, 'whisper', 0.6); put(fx, at('s01_coldopen', 4), 'pianosting', 0.5)
loop(fx, at('s01_coldopen', 5), at('s01_coldopen', 7) + 2.3, 'heart', 0.55)
put(fx, at('s01_coldopen', 7) + 1.2, 'riser', 0.5); put(fx, at('s01_coldopen', 7) + 2.4, 'bodyfall', 0.8); put(fx, at('s01_coldopen', 7) + 2.45, 'splash', 0.9)
s, e = span('s02_title'); put(fx, s + 0.15, 'boom', 0.9); put(fx, s + 0.3, 'sting', 0.6); put(amb, s, 'whispers', 0.25, dur=e - s)
s, e = span('s03_bus'); put(fx, s, 'bus', 0.6, dur=7); loop(amb, s, e, 'wind', 0.25); put(amb, s + 3, 'crows', 0.25, dur=12)
steps(fx, s + 0.7, at('s03_bus', 1), g=0.3)
s, e = span('s04_street'); loop(amb, s, e, 'wind', 0.3); put(amb, s, 'crows', 0.3, dur=10); steps(fx, s, at('s04_street', 2), g=0.3)
put(fx, at('s04_street', 1) + 1.5, 'door', 0.9); put(fx, at('s04_street', 1) + 1.6, 'pianosting', 0.35)
s, e = span('s05_chai'); loop(amb, s, e, 'crickets', 0.3); loop(amb, s, e, 'wind', 0.12); steps(fx, s, at('s05_chai', 1), g=0.25)
put(fx, at('s05_chai', 7), 'pianosting', 0.55); put(amb, at('s05_chai', 5), 'amb1', 0.3, dur=e - at('s05_chai', 5))
s, e = span('s06_flashback'); s2, e2 = span('s07_flashback_water')
put(mus, s + 0.3, 'music_sad', 0.55, dur=e2 - s - 0.3, fin=2, fout=3)
put(fx, s2 - 0.4, 'splash', 0.5); loop(amb, s2, e2, 'drip1', 0.2); put(fx, at('s07_flashback_water', 1) - 0.5, 'moan', 0.25)
s, e = span('s08_warning'); loop(amb, s, e, 'crickets', 0.25); put(amb, s, 'amb1', 0.3, dur=e - s)
put(fx, at('s08_warning', 1), 'sting', 0.35); put(fx, at('s08_warning', 3) - 0.5, 'shutter', 0.6); steps(fx, at('s08_warning', 4) + 0.7, e - 1, g=0.25)
s, e = span('s09_dharamshala'); loop(amb, s, e, 'crickets', 0.18); put(amb, s, 'amb2', 0.25, dur=e - s)
s, e = span('s10_path'); loop(amb, s, at('s10_path', 1) + 1.8, 'crickets', 0.4); loop(amb, s, e, 'wind', 0.25); steps(fx, s, e, g=0.35)
put(fx, at('s10_path', 1) + 1.8, 'whisper', 0.25)
s, e = span('s11_baoli_top'); put(mus, s, 'music_horror', 0.3, dur=e - s, fin=2, fout=2); loop(amb, s, e, 'wind', 0.2); loop(amb, s, e, 'drip1', 0.2)
s, e = span('s12_steps'); put(amb, s, 'amb3', 0.4, dur=e - s); steps(fx, s, e, g=0.3); loop(amb, s, e, 'drip2', 0.25)
for k in range(4): put(fx, at('s12_steps', 1) + 0.33 + k * 2.0, 'shutter', 0.55, dur=0.6)
s, e = span('s13_water'); put(amb, s, 'amb1', 0.4, dur=e - s); loop(amb, s, e, 'drip2', 0.35)
put(fx, at('s13_water', 2) - 0.5, 'whispers', 0.35, dur=5); put(fx, at('s13_water', 2), 'pianosting', 0.5)
loop(fx, at('s13_water', 2) + 1, e, 'heart', 0.5)
s, e = span('s14_camera'); put(fx, s + 0.1, 'shutter', 0.6, dur=0.6); loop(fx, s, e, 'heart2', 0.55)
put(fx, at('s14_camera', 1) + 0.2, 'riser', 0.5); put(fx, at('s14_camera', 1) + 2.4, 'jumpscare', 0.8, dur=3); put(fx, at('s14_camera', 1) + 2.4, 'boom', 0.7)
s, e = span('s15_separated'); put(amb, s, 'amb3', 0.4, dur=e - s); put(fx, s, 'running', 0.6, dur=at('s15_separated', 1) - s - 0.8)
loop(fx, at('s15_separated', 2), e, 'heart', 0.5); put(fx, at('s15_separated', 3), 'sting', 0.4)
s, e = span('s16_hand'); put(amb, s, 'amb2', 0.4, dur=e - s); loop(amb, s, e, 'drip1', 0.45); put(fx, s + 1.0, 'moan', 0.5)
put(fx, s + 1.5, 'sting', 0.6); loop(fx, s, e, 'heart2', 0.5); put(fx, at('s16_hand', 2) + 1.7, 'running', 0.7, dur=e - at('s16_hand', 2) - 1.7)
s, e = span('s17_rising'); put(fx, s, 'running', 0.7, dur=e - s); put(amb, s, 'flood', 0.6, dur=e - s); loop(fx, s, e, 'heart2', 0.5); put(fx, e - 3, 'riser', 0.5)
s, e = span('s18_kaka_top'); put(fx, s + 0.3, 'bodyfall', 0.8); put(amb, s, 'amb1', 0.25, dur=e - s); loop(amb, s, e, 'wind', 0.2)
steps(fx, at('s18_kaka_top', 4) + 0.3, e, g=0.25); loop(fx, at('s18_kaka_top', 5), e, 'drip1', 0.45); put(fx, at('s18_kaka_top', 5) + 3, 'pianosting', 0.5)
s, e = span('s19_dawn'); loop(amb, s, e, 'wind', 0.25); put(amb, s, 'crows', 0.2, dur=12); steps(fx, s, at('s19_dawn', 1) - 0.3, g=0.3)
put(fx, at('s19_dawn', 3) + 2, 'pianosting', 0.45)
s, e = span('s20_photo'); loop(amb, s, e, 'wind', 0.15); steps(fx, s, at('s20_photo', 1), g=0.25)
put(mus, at('s20_photo', 3), 'music_sad', 0.45, skip=40, dur=e - at('s20_photo', 3), fin=2, fout=3); put(fx, at('s20_photo', 5) + 2, 'whisper', 0.4)
s, e = span('s21_city'); loop(amb, s, e, 'city', 0.3); put(amb, s, 'amb2', 0.3, dur=e - s); put(fx, at('s21_city', 1) - 0.3, 'shutter', 0.4, dur=0.6)
put(fx, at('s21_city', 3) - 2.4, 'riser', 0.6); put(fx, at('s21_city', 3), 'jumpscare', 0.95, dur=3); put(fx, at('s21_city', 3), 'boom', 0.9)
s, e = span('s22_outro'); put(mus, s, 'music_horror', 0.4, skip=60, dur=e - s, fin=1, fout=3)

# ---------- mix ----------
def norm(x, peak): m = np.abs(x).max(); return x / m * peak if m > 0 else x
k = int(0.3 * SR)
duck = np.convolve((np.abs(voice) > 0.02).astype(np.float32), np.ones(k) / k, 'same')
duck = 1 - 0.5 * np.clip(duck * 3, 0, 1)
mix = norm(voice, 0.85) + (norm(amb, 0.35) + norm(fx, 0.6) + norm(mus, 0.4)) * duck
mix = np.tanh(mix * 1.1) * 0.92
st = np.stack([mix, mix], 1).astype(np.float32)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', '-', '-c:a', 'pcm_s16le', 'work/mix.wav'], input=st.tobytes())
print('MIX_OK seconds', round(len(mix) / SR, 1))
