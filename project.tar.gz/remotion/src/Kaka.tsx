import React from 'react';

// Hariya Kaka: flat-colour cut-out puppet, thick outlines, every part posable.
// Local coordinates: origin at the feet (centre), up is -y. ~1060 units tall.

export type KakaPose = {
  breathe: number;        // -1..1
  headRot: number;        // degrees, tilt around the neck
  headTurn: number;       // -1..1, fake 3/4 turn (shifts features)
  headDip: number;        // px, lean the head forward/down
  lookX: number; lookY: number; // -1..1 pupil direction
  blink: number;          // 0..1
  brow: number;           // -1 frown .. 1 raised
  mouth: number;          // 0..1 open
  armA: {sh: number; el: number; hand: 'open' | 'point' | 'fist'}; // viewer-left arm (free hand)
  armB: {sh: number; el: number};                                   // viewer-right arm (holds lantern)
  swing: number;          // lantern swing degrees
  flame: number;          // 0..1 flicker
};

const INK = '#1b1310';
const SW = 6;
const C = {
  skin: '#8b5434', skinDk: '#6a3a20', skinLt: '#a0663f',
  white: '#f2eee4', whiteDk: '#cfc5b0', turban: '#f5f2ea', turbanDk: '#d4ccba',
  hair: '#f4f4f0', hairDk: '#c9c9c4', jutti: '#5b3a1f', brass: '#b8892e', brassDk: '#7e5a18',
};
const st = {stroke: INK, strokeWidth: SW, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

const Hand: React.FC<{kind: 'open' | 'point' | 'fist'}> = ({kind}) => (
  <g>
    {kind === 'point' && <path d="M-7,26 L-8,82 Q0,90 8,82 L7,26 Z" fill={C.skin} {...st} />}
    {kind === 'open' && <>
      <path d="M-20,10 L-24,48 Q-18,54 -13,48 L-10,14" fill={C.skin} {...st} />
      <path d="M-8,14 L-8,58 Q-1,64 5,58 L4,14" fill={C.skin} {...st} />
      <path d="M6,12 L10,52 Q17,57 21,50 L16,10" fill={C.skin} {...st} />
    </>}
    <ellipse cx={0} cy={14} rx={22} ry={24} fill={C.skin} {...st} />
    {kind !== 'open' && <path d="M-16,4 Q0,-2 16,4 M-17,16 Q0,10 17,16" fill="none" stroke={INK} strokeWidth={3} />}
    <path d="M18,0 Q32,10 24,28" fill={C.skin} {...st} />
  </g>
);

const Lantern: React.FC<{flame: number}> = ({flame}) => (
  <g>
    <path d="M-26,8 Q0,-34 26,8" fill="none" {...st} stroke={C.brassDk} strokeWidth={7} />
    <path d="M-26,8 Q0,-34 26,8" fill="none" stroke={INK} strokeWidth={2} />
    <rect x={-30} y={8} width={60} height={18} rx={6} fill={C.brass} {...st} />
    <path d="M-28,26 Q-46,70 -28,112 L28,112 Q46,70 28,26 Z" fill={`rgba(255,${200 + flame * 40},120,0.9)`} {...st} />
    <path d="M0,96 Q-12,76 0,50 Q12,76 0,96 Z" fill="#fff6c8" transform={`scale(${0.85 + flame * 0.3})`} style={{transformOrigin: '0px 96px'}} />
    <path d="M-30,30 L-30,110 M30,30 L30,110" stroke={C.brassDk} strokeWidth={6} />
    <rect x={-36} y={110} width={72} height={20} rx={6} fill={C.brass} {...st} />
  </g>
);

// One arm: shoulder at (0,0), hangs down +y. Rotation in SVG degrees (+ = clockwise).
const Arm: React.FC<{sh: number; el: number; children?: React.ReactNode; flip?: boolean}> = ({sh, el, children, flip}) => (
  <g transform={`rotate(${sh})`}>
    <path d="M-28,-8 Q-34,95 -26,186 L26,186 Q34,95 28,-8 Q0,-24 -28,-8 Z" fill={C.white} {...st} />
    <path d={flip ? 'M14,20 Q20,100 14,180' : 'M-14,20 Q-20,100 -14,180'} fill="none" stroke={C.whiteDk} strokeWidth={10} />
    <g transform={`translate(0,180) rotate(${el})`}>
      <path d="M-25,-4 L-22,150 L22,150 L25,-4 Z" fill={C.white} {...st} />
      <path d="M-22,138 L22,138" stroke={INK} strokeWidth={3} />
      <g transform="translate(0,152)">{children}</g>
    </g>
    <circle cx={0} cy={180} r={4} fill={C.whiteDk} />
  </g>
);

const Eye: React.FC<{x: number; side: number; p: KakaPose; id: string}> = ({x, side, p, id}) => {
  const lid = 0.32 + p.blink * 0.68; // old man: eyes always a little hooded
  const ex = x + p.headTurn * 6;
  return (
    <g>
      <clipPath id={id}><ellipse cx={ex} cy={-118} rx={17} ry={10} /></clipPath>
      <ellipse cx={ex} cy={-118} rx={17} ry={10} fill="#e9eef0" />
      <g clipPath={`url(#${id})`}>
        <circle cx={ex + p.lookX * 7} cy={-117 + p.lookY * 3} r={8} fill="#aab9bf" />
        <circle cx={ex + p.lookX * 7} cy={-117 + p.lookY * 3} r={3.5} fill="#7c8c92" />
        <circle cx={ex + p.lookX * 7 - 3} cy={-120 + p.lookY * 3} r={2} fill="#fff" />
        <rect x={ex - 20} y={-130} width={40} height={20 * lid + 2} fill={C.skin} />
      </g>
      <ellipse cx={ex} cy={-118} rx={17} ry={10} fill="none" stroke={INK} strokeWidth={3.5} />
      <path d={`M${ex - 18},${-128 + 20 * lid} Q${ex},${-131 + 20 * lid} ${ex + 18},${-128 + 20 * lid}`} fill="none" stroke={INK} strokeWidth={4} />
      <path d={`M${ex - 12},-102 Q${ex},-98 ${ex + 12},-102`} fill="none" stroke={C.skinDk} strokeWidth={3} />
      <path d={`M${ex + side * 20},-122 l${side * 9},-4 M${ex + side * 20},-116 l${side * 10},1`} stroke={C.skinDk} strokeWidth={2.5} />
    </g>
  );
};

const Head: React.FC<{p: KakaPose; uid: string}> = ({p, uid}) => {
  const t = p.headTurn * 8;
  const browY = -142 - p.brow * 7;
  const browRot = -p.brow * 6;
  return (
    <g>
      <path d="M-24,4 L-22,-50 L22,-50 L24,4 Z" fill={C.skinDk} {...st} />
      <ellipse cx={-64 + t * 0.3} cy={-110} rx={12} ry={20} fill={C.skin} {...st} />
      <ellipse cx={64 + t * 0.3} cy={-110} rx={12} ry={20} fill={C.skin} {...st} />
      <path d="M-62,-172 C-68,-120 -64,-80 -46,-54 C-30,-36 -15,-30 0,-30 C15,-30 30,-36 46,-54 C64,-80 68,-120 62,-172 Z" fill={C.skin} {...st} />
      <path d="M38,-160 C52,-120 50,-80 34,-56" fill="none" stroke={C.skinDk} strokeWidth={12} opacity={0.6} />
      <g transform={`translate(${t},0)`}>
        {/* wrinkles */}
        <path d="M-34,-160 Q0,-166 34,-160 M-26,-151 Q0,-156 26,-151" fill="none" stroke={C.skinDk} strokeWidth={3} />
        <path d="M-20,-78 Q-30,-66 -34,-52 M20,-78 Q30,-66 34,-52" fill="none" stroke={C.skinDk} strokeWidth={3.5} />
        <Eye x={-27} side={-1} p={p} id={uid + 'el'} />
        <Eye x={27} side={1} p={p} id={uid + 'er'} />
        {/* brows: white and bushy */}
        <g transform={`translate(-28,${browY}) rotate(${browRot})`}>
          <path d="M-24,4 Q-12,-12 22,-2 Q8,4 -4,6 Q-14,10 -24,4 Z" fill={C.hair} {...st} strokeWidth={3.5} />
        </g>
        <g transform={`translate(28,${browY}) rotate(${-browRot})`}>
          <path d="M24,4 Q12,-12 -22,-2 Q-8,4 4,6 Q14,10 24,4 Z" fill={C.hair} {...st} strokeWidth={3.5} />
        </g>
        {/* nose */}
        <path d="M-4,-108 Q-9,-94 -15,-84 Q-6,-76 0,-80 Q6,-76 15,-84 Q9,-94 4,-108" fill={C.skinLt} stroke={INK} strokeWidth={3.5} strokeLinejoin="round" />
        {/* mouth */}
        <g transform="translate(0,-56)">
          <ellipse cx={0} cy={2 + p.mouth * 6} rx={13 + p.mouth * 4} ry={2 + p.mouth * 12} fill="#3b0e0a" stroke={INK} strokeWidth={3} />
          {p.mouth > 0.25 && <path d={`M-10,${-1 + p.mouth * 2} Q0,${3 + p.mouth * 2} 10,${-1 + p.mouth * 2}`} stroke="#e8dfcc" strokeWidth={4} fill="none" />}
          <path d={`M-10,${8 + p.mouth * 14} Q0,${12 + p.mouth * 14} 10,${8 + p.mouth * 14}`} stroke={C.skinDk} strokeWidth={3} fill="none" />
        </g>
        {/* moustache: big white handlebar, lifts a little when talking */}
        <g transform={`translate(0,${-74 - p.mouth * 3})`}>
          <path d="M0,-6 C-20,-14 -46,-8 -62,4 C-72,10 -84,6 -90,-8 C-92,6 -82,22 -64,20 C-44,18 -22,14 0,8 C22,14 44,18 64,20 C82,22 92,6 90,-8 C84,6 72,10 62,4 C46,-8 20,-14 0,-6 Z" fill={C.hair} {...st} strokeWidth={4.5} />
          <path d="M-12,0 Q-34,4 -54,10 M12,0 Q34,4 54,10" stroke={C.hairDk} strokeWidth={3} fill="none" />
        </g>
        <path d="M-14,-40 Q0,-34 14,-40" stroke={C.hairDk} strokeWidth={3} fill="none" />
      </g>
      {/* pagdi: wide, wrapped Rajasthani turban */}
      <path d="M-96,-176 C-120,-214 -104,-262 -60,-280 C-20,-296 30,-296 66,-282 C110,-262 122,-214 98,-176 Q0,-150 -96,-176 Z" fill={C.turban} {...st} />
      <path d="M-100,-186 Q-20,-150 104,-196 M-108,-214 Q-10,-172 110,-232 M-96,-248 Q0,-206 92,-262 M-60,-276 Q10,-244 50,-288" stroke={C.turbanDk} strokeWidth={9} fill="none" />
      <path d="M-100,-186 Q-20,-150 104,-196 M-108,-214 Q-10,-172 110,-232 M-96,-248 Q0,-206 92,-262" stroke={INK} strokeWidth={3} fill="none" />
      <path d="M-70,-160 Q0,-140 70,-160 L74,-180 Q0,-160 -74,-180 Z" fill={C.turbanDk} {...st} strokeWidth={4} />
      <path d="M96,-200 Q130,-170 118,-120 Q112,-100 100,-96 Q110,-140 88,-176 Z" fill={C.turban} {...st} strokeWidth={4.5} />
    </g>
  );
};

export const Kaka: React.FC<{p: KakaPose; uid?: string}> = ({p, uid = 'k'}) => {
  const br = 1 + p.breathe * 0.012;
  return (
    <g>
      {/* feet + legs (dhoti) */}
      <ellipse cx={-50} cy={-12} rx={44} ry={16} fill={C.jutti} {...st} />
      <ellipse cx={50} cy={-12} rx={44} ry={16} fill={C.jutti} {...st} />
      <path d="M-62,-26 L-58,-60 L-36,-60 L-34,-26 Z M34,-26 L36,-60 L58,-60 L62,-26 Z" fill={C.skinDk} {...st} />
      <path d="M-108,-430 C-118,-300 -100,-160 -74,-56 L-22,-56 C-14,-170 -10,-300 0,-410 C10,-300 14,-170 22,-56 L74,-56 C100,-160 118,-300 108,-430 Z" fill={C.white} {...st} />
      <path d="M-70,-360 Q-60,-220 -50,-80 M70,-360 Q60,-220 50,-80 M-6,-400 Q-30,-330 -8,-250" stroke={C.whiteDk} strokeWidth={8} fill="none" />
      {/* torso + everything above rides on the breath */}
      <g transform={`translate(0,-420) scale(${1 + (br - 1) * 0.4},${br}) translate(0,420)`}>
        <g transform="translate(-86,-748)">
          <Arm sh={p.armA.sh} el={p.armA.el}><Hand kind={p.armA.hand} /></Arm>
        </g>
        <path d="M-88,-772 C-104,-700 -110,-560 -118,-372 L118,-372 C110,-560 104,-700 88,-772 C40,-790 -40,-790 -88,-772 Z" fill={C.white} {...st} />
        <path d="M70,-740 C82,-620 88,-500 92,-380" stroke={C.whiteDk} strokeWidth={16} fill="none" />
        <path d="M-26,-782 L0,-744 L26,-782" fill="none" {...st} strokeWidth={4} />
        <path d="M0,-744 L0,-600" stroke={INK} strokeWidth={3.5} />
        <path d="M-92,-770 C-60,-790 -30,-784 -14,-770 C10,-700 40,-600 70,-470 L30,-452 C10,-560 -30,-660 -70,-720 C-84,-700 -98,-640 -104,-560 L-116,-560 C-110,-660 -104,-730 -92,-770 Z" fill="#7a1f24" {...st} />
        <path d="M-40,-760 C-10,-680 20,-590 50,-470" stroke="#5a1418" strokeWidth={8} fill="none" />
        <path d="M30,-452 L70,-470 M36,-440 l4,14 M48,-446 l4,14 M60,-452 l4,14" stroke="#d9a441" strokeWidth={4} />
        {[-720, -680, -640].map((y) => <circle key={y} cx={8} cy={y} r={4} fill={C.whiteDk} stroke={INK} strokeWidth={2} />)}
        <g transform={`translate(0,${-776 + p.headDip}) rotate(${p.headRot})`}>
          <g transform="scale(1.32)"><Head p={p} uid={uid} /></g>
        </g>
        <g transform="translate(86,-748)">
          <Arm sh={p.armB.sh} el={p.armB.el} flip>
            <g transform="translate(0,10)">
              {/* keep the lantern hanging straight down whatever the arm does */}
              <g transform={`rotate(${-(p.armB.sh + p.armB.el) + p.swing})`}><g transform="translate(0,18) scale(1.35)"><Lantern flame={p.flame} /></g></g>
              <Hand kind="fist" />
            </g>
          </Arm>
        </g>
      </g>
    </g>
  );
};
