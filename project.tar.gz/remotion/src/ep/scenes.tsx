import React from 'react';
import {AbsoluteFill, random} from 'remotion';
import '@fontsource/noto-sans-devanagari/700.css';
import '@fontsource/noto-sans-devanagari/900.css';
import '@fontsource/creepster/400.css';
import {KAKA, ARJUN, KABIR, KESAR, KESAR_ALIVE} from '../puppet/cast';
import {Look, basePose, Pose} from '../puppet/Person';
import {Ctx, kf, noise, travel, gait, GRADE, Fog, Dust, Glow, Flash, Ripple, Drips, WaterRise, Footprints, Black, Actor, Subtitle} from './kit';
import {Stage, livePose, Shot, fadeEdges} from './Stage';
import {PhotoContent, CameraLCD, Portrait, Blanket, GhostHand, Accusers, Tears, WaterSurface} from './props';

const G = 1010; // ground line
const S = 0.62; // standard scale for two-shots

const lanternArm = (up: number) => ({sh: -8 - 87 * up, el: -22 - 33 * up, hand: 'fist' as const, prop: 'lantern' as const});
const hang = {L: {sh: 8, el: 10, hand: 'open' as const}, R: {sh: -8, el: -10, hand: 'open' as const}};
const sw = (g: {armSwing: number}) => ({armL: {sh: 8 + g.armSwing, el: 14, hand: 'open' as const}, armR: {sh: -8 + g.armSwing, el: -14, hand: 'open' as const}});

type SceneFn = (f: number, c: Ctx) => React.ReactElement;

// ---------- 1. cold open ----------
const s01: SceneFn = (f, c) => {
  const fall = kf(f, [[c.at(7) + 40, 0], [c.at(7) + 75, 1]]);
  const lean = kf(f, [[c.at(5), 0], [c.at(5) + 20, 1]]);
  const kaka: Actor = {L: KAKA, uid: 'k1', speaker: 'KAKA', pose: {x: 1180 - fall * 300, y: G + fall * 160, scale: 0.6, face: -1, tint: 0.78,
    rot: -fall * 70, alpha: 1 - fall * 0.9, headDip: lean * 14, lookY: lean, lookX: 0.4, armR: lanternArm(kf(f, [[c.at(3), 0], [c.at(3) + 25, 1]])), armL: hang.L,
    swing: Math.sin(f / 12) * 6, fear: kf(f, [[c.at(4), 0], [c.at(4) + 10, 0.6]])}};
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(3), cam: {x: 520, y: 880, z: 1.6}}, {from: c.at(4), cam: {x: 500, y: 930, z: 2.3}},
    {from: c.at(5), cam: {on: 'k1', z: 1.8}}, {from: c.at(6), cam: {on: 'k1', z: 2.3}}, {from: c.at(7), cam: 'wide'}];
  const lx = 1180 - fall * 300 - 240 * 0.6 * kf(f, [[c.at(3), 0.3], [c.at(3) + 25, 1]]);
  return <>
    <Stage ctx={c} f={f} bg="baoli_night" grade={GRADE.deep} actors={[kaka]} shots={shots} shake={f > c.at(7) + 60 && f < c.at(7) + 90 ? 18 : 0}
      under={<><Ripple f={f} x={480} y={960} from={c.at(3)} w={260} /><Ripple f={f} x={480} y={960} from={c.at(7) + 70} n={6} w={360} /></>}
      over={<><Glow x={lx} y={G - 560 * 0.6 - 120 * kf(f, [[c.at(3), 0], [c.at(3) + 25, 1]])} r={360} f={f} k={0.5 * (1 - fall)} /><Fog f={f} /></>} />
    <Black o={Math.max(fadeEdges(f, c.total, 40, 1), kf(f, [[c.at(7) + 80, 0], [c.at(7) + 84, 1]], false))} />
  </>;
};

// ---------- 2. title ----------
const s02: SceneFn = (f, c) => {
  const flick = random('tf' + Math.floor(f / 3)) > 0.88 ? 0.4 : 1;
  return <AbsoluteFill style={{background: '#000', alignItems: 'center', justifyContent: 'center'}}>
    <div style={{fontFamily: "'Creepster', serif", fontWeight: 400, fontSize: 200, letterSpacing: 6, color: '#b3121b', opacity: kf(f, [[0, 0], [20, 1], [c.total - 20, 1], [c.total, 0]]) * flick,
      transform: `scale(${1 + f / 3000})`, textShadow: '0 0 40px rgba(255,0,0,0.5), 0 8px 0 #3a0003'}}>Baawdi Ki Pukaar</div>
    <div style={{position: 'absolute', top: 700, fontFamily: "'Noto Sans Devanagari', sans-serif", fontStyle: 'italic', fontSize: 46, color: '#9a8f86', opacity: kf(f, [[30, 0], [60, 1], [c.total - 20, 1], [c.total, 0]])}}>Ek bawdi... jo naam pukaarti hai</div>
    <svg width={1920} height={1080} style={{position: 'absolute'}}>{[0, 1, 2, 3, 4].map((i) => {
      const x = 640 + i * 160 + random('dx' + i) * 60, l = Math.min(1, f / 120) * (40 + random('dl' + i) * 120);
      return <path key={i} d={`M${x},610 L${x},${610 + l}`} stroke="#8a0d14" strokeWidth={10} strokeLinecap="round" />;
    })}</svg>
  </AbsoluteFill>;
};

// ---------- 3. bus stop ----------
const s03: SceneFn = (f, c) => {
  const a = travel(f, 20, c.at(1), 2150, 800); const k = travel(f, 40, c.at(1) + 30, 2350, 1120);
  const laugh = f > c.at(5) && f < c.at(5) + 70;
  const arjun: Actor = {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {y: G, scale: S, ...a, face: a.moving ? -1 : 1, lean: 0,
    smile: f > c.at(3) ? 0.8 : 0.4, mouth: laugh ? 0.5 + Math.abs(Math.sin(f / 3)) * 0.4 : undefined, headRot: laugh ? -10 : undefined,
    armL: f > c.at(3) && f < c.at(4) ? {sh: 40 + Math.sin(f / 9) * 10, el: 70, hand: 'open'} : sw(a).armL, armR: sw(a).armR}};
  const phoneUp = f > c.at(2) && f < c.at(3);
  const kabir: Actor = {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {y: G, scale: S, ...k, face: -1, lean: 0,
    lookY: phoneUp ? -0.8 : 0, fear: f > c.at(4) ? 0.6 : 0.15,
    armR: phoneUp ? {sh: -150, el: -20 + Math.sin(f / 6) * 15, hand: 'fist', prop: 'phone'} : {sh: -8 + k.armSwing, el: -40, hand: 'fist', prop: 'phone'},
    armL: f > c.at(4) && f < c.at(5) ? {sh: 30, el: 125, hand: 'open'} : sw(k).armL}};
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(1), cam: {on: 'ar', z: 1.6}}, {from: c.at(1) + Math.round((c.at(2) - c.at(1)) * 0.55), cam: {on: 'kb', z: 1.6}},
    {from: c.at(2), cam: {on: 'kb'}}, {from: c.at(3), cam: {on: 'ar'}}, {from: c.at(4), cam: {on: 'kb'}}, {from: c.at(5), cam: {x: 960, y: 640, z: 1.25}}];
  return <><Stage ctx={c} f={f} bg="bus_stop_day" grade={GRADE.day} actors={[arjun, kabir]} shots={shots} over={<Dust f={f} n={30} />} /><Black o={fadeEdges(f, c.total, 30)} /></>;
};

// ---------- 4. village street ----------
const s04: SceneFn = (f, c) => {
  const slam = c.at(1) + 45;
  const a = travel(f, 0, c.at(2), 380, 1000); const k = travel(f, 0, c.at(2), 130, 720);
  const jump = kf(f, [[slam, 0], [slam + 4, -30], [slam + 12, 0]], false);
  const arjun: Actor = {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {y: G, scale: S, ...a, bob: a.bob + jump, smile: f > c.at(3) ? 0.9 : 0.2, ...sw(a), face: 1}};
  const kabir: Actor = {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {y: G, scale: S, ...k, bob: k.bob + jump * 1.5, lookX: Math.sin(f / 40), fear: f > slam ? 0.8 : 0.3,
    shake: f > slam ? f : 0, ...sw(k), face: 1}};
  const shots: Shot[] = [{from: 0, cam: {x: 700, y: 640, z: 1.15}}, {from: c.at(2), cam: {on: 'kb'}}, {from: c.at(3), cam: {on: 'ar'}}];
  return <><Stage ctx={c} f={f} bg="village_street_dusk" grade={GRADE.dusk} actors={[arjun, kabir]} shots={shots} shake={f > slam && f < slam + 15 ? 22 : 0}
    over={<Dust f={f} n={30} />} /><Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 5. chai stall ----------
const s05: SceneFn = (f, c) => {
  const a = travel(f, 0, c.at(1) - 20, 2200, 1480); const k = travel(f, 10, c.at(1), 2450, 1750);
  const jolt = f > c.at(4) && f < c.at(4) + 40;
  const kaka: Actor = {L: KAKA, uid: 'ka', speaker: 'KAKA', pose: {x: 1150, y: G, scale: S, face: 1, brow: f > c.at(5) ? -0.8 : -0.2,
    armR: {sh: -20 + (jolt ? Math.sin(f) * 14 : 0), el: -95, hand: 'fist', prop: 'glass'}, armL: hang.L, lookX: f > c.at(4) ? 0.6 : 0.3, headDip: f > c.at(7) ? 10 : 0}};
  const arjun: Actor = {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {y: G, scale: S, ...a, ...sw(a), face: -1, smile: 0.5}};
  const kabir: Actor = {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {y: G, scale: S, ...k, ...sw(k), face: -1,
    armL: f > c.at(6) && f < c.at(7) ? {sh: 60, el: 60, hand: 'open'} : sw(k).armL, armR: f > c.at(6) && f < c.at(7) ? {sh: -60, el: -60, hand: 'open'} : sw(k).armR}};
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(1), cam: {on: 'ka', z: 2.2}}, {from: c.at(2), cam: {on: 'ka'}}, {from: c.at(3), cam: {on: 'ar'}},
    {from: c.at(4), cam: {x: 1250, y: 640, z: 1.4}}, {from: c.at(5), cam: {on: 'ka', z: 2.0}}, {from: c.at(6), cam: {on: 'kb'}}, {from: c.at(7), cam: {on: 'ka', z: 2.5}}];
  return <><Stage ctx={c} f={f} bg="chai_stall_dusk" grade={GRADE.dusk} actors={[kaka, arjun, kabir]} shots={shots}
    over={<><Glow x={861} y={555} r={300} f={f} k={0.4} /><Dust f={f} n={20} /></>} /><Black o={fadeEdges(f, c.total, 12, 20)} /></>;
};

// ---------- 6. flashback: Kesar accused ----------
const s06: SceneFn = (f, c) => {
  const leave = travel(f, c.at(2) + 30, c.total - 10, 960, -300);
  const cry = f > c.at(1);
  const kesar: Actor = {L: KESAR_ALIVE, uid: 'kl', pose: {x: leave.x, y: G, scale: 0.68, ...(f > c.at(2) + 30 ? leave : {}), face: f > c.at(2) + 30 ? -1 : 1,
    headDip: cry ? 18 : 0, lookY: cry ? 0.8 : 0, brow: cry ? 0.6 : 0, mouth: cry ? 0.15 + Math.abs(Math.sin(f / 9)) * 0.15 : 0,
    armL: cry && f < c.at(2) + 30 ? {sh: 30, el: 135, hand: 'open'} : hang.L, armR: cry && f < c.at(2) + 30 ? {sh: -30, el: -135, hand: 'open'} : hang.R, hairWave: Math.sin(f / 20) * 0.4}};
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(1), cam: {on: 'kl', z: 1.5}}, {from: c.at(2), cam: 'wide'}];
  const p = livePose(kesar, c, f);
  return <><Stage ctx={c} f={f} bg="haveli_flashback" grade={GRADE.night} actors={[kesar]} shots={shots} filter="sepia(0.85) contrast(1.05)"
    over={<>{cry && f < c.at(2) + 30 && <Tears x={p.x - 50} y={p.y - 900 * 0.68} f={f} />}<Accusers f={f} on={kf(f, [[c.at(1), 0], [c.at(1) + 20, 1], [c.at(2) + 20, 1], [c.at(2) + 40, 0]])} /></>} />
    <Black o={fadeEdges(f, c.total, 25, 25)} /></>;
};

// ---------- 7. flashback: drowning ----------
const s07: SceneFn = (f, c) => {
  const sink = kf(f, [[c.at(3), 0], [c.at(3) + 90, 1]]);
  const flail = f < c.at(3) + 60;
  const kesar: Actor = {L: KESAR_ALIVE, uid: 'kw', speaker: 'KESAR', pose: {x: 870 + Math.sin(f / 25) * 30, y: 1530 + Math.sin(f / 8) * 14 + sink * 600, scale: 0.75,
    fear: 0.9, brow: 1, lookY: -0.6, armL: flail ? {sh: 150 + Math.sin(f / 5) * 25, el: 30, hand: 'open'} : hang.L,
    armR: flail ? {sh: -150 + Math.sin(f / 6) * 25, el: -30, hand: 'open'} : hang.R, mouth: f < c.at(2) ? 0.3 + Math.abs(Math.sin(f / 7)) * 0.3 : undefined}};
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(1), cam: {on: 'kw', z: 1.7}}, {from: c.at(2), cam: {x: 960, y: 600, z: 1.1}}];
  return <><Stage ctx={c} f={f} bg="baoli_water_night" grade={GRADE.night} actors={[kesar]} shots={shots} filter="sepia(0.85) contrast(1.05)"
    over={<><WaterSurface y={880} f={f} /><Ripple f={f} x={870} y={890} from={0} n={5} w={420} /></>} />
    <Black o={Math.max(fadeEdges(f, c.total, 20, 30), kf(f, [[c.at(3) + 60, 0], [c.total - 30, 0.5]]))} /></>;
};

// ---------- 8. the warning ----------
const s08: SceneFn = (f, c) => {
  const up = kf(f, [[0, 0], [25, 1]]);
  const wag = f > c.at(1) && f < c.at(2) ? Math.sin(f * 0.7) * 14 : 0;
  const go = c.at(4) + 20;
  const a = travel(f, go, c.total, 720, -400); const k = travel(f, go - 10, c.total, 470, -650);
  const camUp = f > c.at(2) + 50 && f < c.at(4);
  const kaka: Actor = {L: KAKA, uid: 'ka', speaker: 'KAKA', pose: {x: 1400, y: G, scale: S, face: -1, armR: lanternArm(up), brow: f > c.at(1) ? 0.9 : -0.6,
    armL: f > c.at(1) && f < c.at(2) ? {sh: 42, el: 112 + wag, hand: 'point'} : hang.L, swing: Math.sin(f / 9) * 8 * Math.exp(-f / 60), headDip: f > c.at(1) ? 12 : 0,
    lookX: f > go ? 0.8 : 0.2}};
  const arjun: Actor = {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {x: a.x, y: G, scale: S, face: f > go ? -1 : 1, ...(f > go ? {...a, ...sw(a)} : {}), smile: 0.6,
    armR: camUp ? {sh: -40, el: -120, hand: 'fist', prop: 'camera'} : (f > go ? sw(a).armR : hang.R)}};
  const kabir: Actor = {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {x: k.x, y: G, scale: S, face: f > go ? -1 : 1, ...(f > go ? {...k, ...sw(k)} : {}),
    fear: f > c.at(1) ? 0.9 : 0.4, shake: f > c.at(1) ? f : 0}};
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(0) + 10, cam: {on: 'ka', z: 2}}, {from: c.at(1), cam: {on: 'ka', z: 1.6}},
    {from: c.at(2), cam: {on: 'kb'}}, {from: c.at(2) + 50, cam: {on: 'ar'}}, {from: c.at(3), cam: {on: 'ar'}}, {from: c.at(4), cam: 'wide'}, {from: c.at(4) + 120, cam: {on: 'ka', z: 2.1}}];
  return <><Stage ctx={c} f={f} bg="chai_stall_night" grade={GRADE.night} actors={[kaka, arjun, kabir]} shots={shots}
    over={<><Glow x={1400 + 260 * S * up} y={G - 560 * S - 270 * S * up} r={420} f={f} /><Flash f={f} at={[c.at(3) - 15]} /><Glow x={1263} y={373} r={260} f={f} k={0.35} /><Fog f={f} k={0.1} /></>} />
    <Black o={fadeEdges(f, c.total, 15, 30)} /></>;
};

// ---------- 9. dharamshala room ----------
const s09: SceneFn = (f, c) => {
  const sigh = kf(f, [[c.at(3), 0], [c.at(3) + 20, 1], [c.at(3) + 50, 0]]);
  const kabirP: Partial<Pose> = {x: 560, y: G, scale: S, fear: 0.7, shake: f, headDip: sigh * 16, armL: {sh: 10, el: 10, hand: 'open'},
    armR: f > c.at(4) ? {sh: -70, el: -40, hand: 'point'} : {sh: -10, el: -10, hand: 'open'}};
  const kabir: Actor = {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: kabirP};
  const torchFlick = f < c.at(1) ? (Math.floor(f / 20) % 2) : 0;
  const arjun: Actor = {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {x: 1300, y: G, scale: S, face: -1, smile: 0.5, torchOn: torchFlick,
    armR: {sh: -30, el: -80, hand: 'fist', prop: 'torch'}, armL: f > c.at(2) && f < c.at(3) ? {sh: 50, el: 60, hand: 'open'} : hang.L}};
  const p = livePose(kabir, c, f);
  return <><Stage ctx={c} f={f} bg="dharamshala_room_night" grade={GRADE.night} actors={[kabir, arjun]}
    over={<><svg width={1920} height={1080} style={{position: 'absolute'}}><Blanket p={p} h={KABIR.height} /></svg><Glow x={335} y={450} r={300} f={f} k={0.4} /></>} />
    <Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 10. the path ----------
const s10: SceneFn = (f, c) => {
  const a = travel(f, 0, c.total, 200, 1500); const k = travel(f, 0, c.total, -80, 1220);
  const actors: Actor[] = [
    {L: KABIR, uid: 'kb', pose: {y: G, scale: S, ...k, ...sw(k), face: 1, fear: 0.6, torchOn: 1, armR: {sh: -60 + k.armSwing * 0.3, el: -30, hand: 'fist', prop: 'torch'}}},
    {L: ARJUN, uid: 'ar', pose: {y: G, scale: S, ...a, ...sw(a), face: 1, torchOn: 1, armR: {sh: -60 + a.armSwing * 0.3, el: -30, hand: 'fist', prop: 'torch'}}},
  ];
  return <><Stage ctx={c} f={f} bg="desert_path_night" grade={GRADE.deep} actors={actors} shots={[{from: 0, cam: {x: 600 + f * 1.2, y: 600, z: 1.2}}]} over={<Fog f={f} />} />
    <Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 11. stepwell top ----------
const s11: SceneFn = (f, c) => {
  const a = travel(f, 0, c.at(1) - 10, 2100, 1350); const k = travel(f, 10, c.at(1), 2300, 1620);
  const live = f > c.at(2);
  const actors: Actor[] = [
    {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {y: G, scale: S, ...a, ...sw(a), face: -1, smile: 0.9, torchOn: 1,
      armR: {sh: -20, el: -40, hand: 'fist', prop: 'torch'}, armL: f > c.at(1) && f < c.at(2) ? {sh: 70, el: 20, hand: 'point'} : sw(a).armL}},
    {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {y: G, scale: S, ...k, ...sw(k), face: -1, fear: 0.7, smile: live ? 0.4 : 0, shake: f,
      armR: live ? {sh: -150, el: -40, hand: 'fist', prop: 'phone'} : {sh: -10, el: -40, hand: 'fist', prop: 'phone'}}},
  ];
  return <><Stage ctx={c} f={f} bg="baoli_night" grade={GRADE.night} actors={actors} shots={[{from: 0, cam: 'wide'}, {from: c.at(1), cam: {on: 'ar'}}, {from: c.at(2), cam: {on: 'kb'}}]}
    over={<Fog f={f} />} /><Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 12. going down ----------
const s12: SceneFn = (f, c) => {
  const p = kf(f, [[0, 0], [c.total, 1]], false);
  const flashes = [c.at(1) + 10, c.at(1) + 70, c.at(1) + 130, c.at(1) + 190];
  const a = gait(f / 6), k = gait(f / 6 + 1);
  const actors: Actor[] = [
    {L: KABIR, uid: 'kb', pose: {x: 1180 - p * 260, y: 1080 - p * 200, scale: 0.6 - p * 0.24, ...k, ...sw(k), face: -1, fear: 0.8, torchOn: 1, armR: {sh: -40, el: -30, hand: 'fist', prop: 'torch'}}},
    {L: ARJUN, uid: 'ar', pose: {x: 1420 - p * 330, y: 1130 - p * 210, scale: 0.66 - p * 0.26, ...a, face: -1, armR: {sh: -40, el: -120, hand: 'fist', prop: 'camera'}, armL: sw(a).armL}},
  ];
  return <><Stage ctx={c} f={f} bg="baoli_steps_night" grade={GRADE.deep} actors={actors} shots={[{from: 0, cam: {x: 960, y: 560, z: 1.1}}]}
    over={<Flash f={f} at={flashes} />} /><Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 13. the water ----------
const s13: SceneFn = (f, c) => {
  const grab = c.at(3) + 35;
  const g = kf(f, [[grab, 0], [grab + 8, 1]]);
  const actors: Actor[] = [
    {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {x: 950, y: 870, scale: 0.5, fear: 0.9, lookX: 1, shake: f > c.at(2) ? f : 0,
      mouth: f > c.at(3) && f < grab ? 0.8 : 0, armR: {sh: -10, el: -40, hand: 'fist', prop: 'phone'}}},
    {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {x: 1190 - g * 50, y: 870, scale: 0.5, face: -1, fear: f > c.at(1) ? 0.6 : 0, brow: f > c.at(4) ? -0.9 : 0, lookX: f > c.at(1) ? -1 : 0,
      armL: {sh: 20, el: 30, hand: 'fist', prop: 'torch'}, torchOn: 1, armR: {sh: -8 - g * 92, el: -10 + g * 80, hand: 'open'}}},
  ];
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(1), cam: {x: 870, y: 960, z: 1.8}}, {from: c.at(2), cam: {x: 870, y: 970, z: 2.4}},
    {from: c.at(3), cam: {x: 1060, y: 560, z: 1.9}}, {from: c.at(4), cam: {on: 'ar', z: 2}}];
  return <><Stage ctx={c} f={f} bg="baoli_water_night" grade={GRADE.deep} actors={actors} shots={shots}
    under={<Ripple f={f} x={870} y={980} from={c.at(1) + 20} n={5} w={380} />} over={<Fog f={f} k={0.1} />} /><Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 14. the photo ----------
const s14: SceneFn = (f, c) => {
  if (f < c.at(2)) {
    const ghostIn = kf(f, [[c.at(1) + 40, 0], [c.at(1) + 70, 1]]);
    return <><CameraLCD f={f} shake={6}>
      <PhotoContent bg="baoli_steps_night" w={1460} h={800} people={[
        {L: KESAR, uid: 'pk', p: basePose({x: 1150, y: 1060, scale: 0.75, faceless: true, alpha: ghostIn, armL: {sh: 10, el: 10, hand: 'claw'}, armR: {sh: -10, el: -10, hand: 'claw'}})},
        {L: KABIR, uid: 'pb', p: basePose({x: 900, y: 1080, scale: 0.7, fear: 0.6, armR: {sh: -10, el: -40, hand: 'fist', prop: 'phone'}})},
      ]} />
    </CameraLCD><Black o={fadeEdges(f, c.total, 6, 1)} /></>;
  }
  const actors: Actor[] = [
    {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {x: 620, y: G, scale: S, fear: 1, shake: f, lookX: 0.6}},
    {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {x: 900, y: G, scale: S, face: -1, fear: 1, shake: f * 0.5, armR: {sh: -40, el: -120, hand: 'fist', prop: 'camera'}}},
  ];
  return <><Stage ctx={c} f={f} bg="baoli_steps_night" grade={GRADE.deep} actors={actors} /><Black o={fadeEdges(f, c.total, 1, 8)} /></>;
};

// ---------- 15. separated ----------
const s15: SceneFn = (f, c) => {
  const stop = c.at(1) - 25;
  const r = travel(f, 0, stop, -200, 900, true);
  const lookDown = f > c.at(3);
  const arjun: Actor = {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {y: G, scale: 0.66, ...r, face: f > stop + 15 ? -1 : 1, torchOn: 1,
    armR: {sh: -50 + (f < stop ? r.armSwing : 0), el: -30, hand: 'fist', prop: 'torch'}, armL: f < stop ? sw(r).armL : hang.L,
    fear: f > stop ? 0.9 : 0.6, headDip: lookDown ? 14 : 0, lookY: lookDown ? 1 : 0, lookX: lookDown ? -0.7 : 0,
    mouth: f > c.at(4) && f < c.at(4) + 40 ? 0.5 : (f > c.at(4) + 40 ? 0 : undefined), shake: f > c.at(3) ? f * 0.4 : 0}};
  const shots: Shot[] = [{from: 0, cam: {x: 400 + f * 1.6, y: 620, z: 1.25}}, {from: c.at(1), cam: {on: 'ar', z: 1.9}}, {from: c.at(2), cam: 'wide'},
    {from: c.at(3), cam: {x: 400, y: 900, z: 1.8}}, {from: c.at(4), cam: {on: 'ar', z: 2.3}}];
  return <><Stage ctx={c} f={f} bg="baoli_stairs_dark" grade={GRADE.deep} actors={[arjun]} shots={shots} over={<Fog f={f} k={0.08} />} /><Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 16. the hand ----------
const s16: SceneFn = (f, c) => {
  const reach = kf(f, [[20, 0], [c.at(0) + 70, 1]]);
  const run = c.at(2) + 50;
  const r = travel(f, run, c.total, 960, 2300, true);
  const arjun: Actor = {L: ARJUN, uid: 'ar', pose: {x: r.x, y: G, scale: 0.66, ...(f > run ? r : {}), face: 1, fear: 1, shake: f < run ? f : 0, torchOn: 1,
    blink: f > c.at(2) + 15 && f < run ? 1 : undefined, armR: {sh: -40, el: -30, hand: 'fist', prop: 'torch'}}};
  const shX = 960 - 95 * 0.66, shY = G - 740 * 0.66 * ARJUN.height;
  return <><Stage ctx={c} f={f} bg="baoli_stairs_dark" grade={GRADE.deep} actors={[arjun]} shots={[{from: 0, cam: {x: 960, y: 420, z: 2.2}}, {from: run, cam: {x: 960, y: 600, z: 1.3}}]}
    over={f < run + 10 ? <GhostHand x={shX - 260 * (1 - reach)} y={shY - 40} a={20} len={700} f={f} /> : null} />
    <Black o={fadeEdges(f, c.total, 6, 10)} /></>;
};

// ---------- 17. water rising ----------
const s17: SceneFn = (f, c) => {
  const p = kf(f, [[0, 0], [c.total, 1]], false);
  const g = gait(f / 3.2, 1, true);
  const arjun: Actor = {L: ARJUN, uid: 'ar', pose: {x: 960 + Math.sin(p * 6) * 80, y: 880 + p * 260, scale: 0.36 + p * 0.5, ...g, face: 1, fear: 1, torchOn: 1,
    armR: {sh: -50 + g.armSwing, el: -30, hand: 'fist', prop: 'torch'}, armL: sw(g).armL}};
  const prints: [number, number][] = Array.from({length: 14}).map((_, i) => [945 + (i % 2) * 30, 870 + i * 15]);
  return <><Stage ctx={c} f={f} bg="baoli_steps_night" grade={GRADE.deep} actors={[arjun]} shots={[{from: 0, cam: {x: 960, y: 720, z: 1.15}}]} shake={6}
    under={<><WaterRise f={f} level={790} bottom={800 + p * 330} /><Footprints pts={prints} f={f} from={20} every={30} color="rgba(120,160,200,0.5)" /></>} /><Black o={fadeEdges(f, c.total)} /></>;
};

// ---------- 18. Kaka at the top ----------
const s18: SceneFn = (f, c) => {
  const lie = kf(f, [[0, 1], [c.at(1) - 10, 1], [c.at(1) + 10, 0]]);
  const go = c.at(4) + 10;
  const kk = travel(f, go, c.at(5) + 260, 1400, 2300); const aa = travel(f, go + 15, c.at(5) + 275, 1100, 2050);
  const kaka: Actor = {L: KAKA, uid: 'ka', speaker: 'KAKA', pose: {x: kk.x, y: G, scale: S, face: f > go ? 1 : -1, ...(f > go ? {...kk, ...sw(kk), face: 1 as const} : {}), armR: lanternArm(f > c.at(3) ? 1 : 0.3),
    smile: f > c.at(3) ? 0.6 : 0.2, brow: 0.2, swing: Math.sin(f / 11) * 6}};
  const arjun: Actor = {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {x: aa.x, y: G, scale: S, rot: lie * 80, face: 1, ...(f > go ? {...aa, ...sw(aa), face: 1 as const} : {}),
    fear: f < c.at(2) ? 1 : 0.3, shake: f < c.at(2) ? f : 0, torchOn: 0, armR: {sh: -10, el: -20, hand: 'fist', prop: 'torch'}, lookX: f > c.at(5) ? 0.5 : 0, lookY: f > c.at(5) ? 1 : 0}};
  const feet = f > c.at(5);
  const prints: [number, number][] = Array.from({length: 16}).map((_, i) => [1400 + i * 60, G + 4 + (i % 2) * 8]);
  const shots: Shot[] = [{from: 0, cam: {x: 1150, y: 880, z: 1.5}}, {from: c.at(1), cam: {on: 'ar'}}, {from: c.at(2), cam: {on: 'ka'}}, {from: c.at(3), cam: {on: 'ka', z: 2.4}},
    {from: c.at(4), cam: 'wide'}, {from: c.at(5), cam: {x: kk.x, y: G - 120, z: 2.6}}];
  const kp = livePose(kaka, c, f);
  return <><Stage ctx={c} f={f} bg="baoli_night" grade={GRADE.night} actors={[kaka, arjun]} shots={shots}
    under={<Footprints pts={prints} f={f} from={go} every={9} color="rgba(15,25,40,0.85)" />}
    over={<><Glow x={kp.x + (kp.face === 1 ? 1 : -1) * 220 * S} y={G - 600 * S} r={380} f={f} /><Drips f={f} x={kp.x} y={G - 190} on={feet} /><Fog f={f} k={0.1} /></>} />
    <Black o={fadeEdges(f, c.total, 15, 30)} /></>;
};

// ---------- 19. dawn ----------
const s19: SceneFn = (f, c) => {
  const a = travel(f, 0, c.at(1) - 10, -250, 760);
  const turn = f > c.at(3);
  const actors: Actor[] = [
    {L: KABIR, uid: 'kb', speaker: 'KABIR', pose: {x: 1460, y: 900, scale: 0.55, face: -1, fear: f < c.at(1) ? 0.9 : 0.3, shake: f < c.at(1) ? f : 0, smile: f > c.at(1) ? 0.5 : 0,
      armL: {sh: 30, el: 120, hand: 'open'}, armR: {sh: -30, el: -120, hand: 'open'}}},
    {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {y: G, scale: S, ...a, ...sw(a), face: turn ? -1 : 1, fear: turn ? 0.8 : 0.2,
      armL: f > c.at(2) && f < c.at(3) ? {sh: -70, el: 10, hand: 'point'} : sw(a).armL}},
  ];
  const prints: [number, number][] = Array.from({length: 14}).map((_, i) => [700 - i * 60, G + 10 + (i % 2) * 8]);
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(1), cam: {on: 'kb'}}, {from: c.at(2), cam: {on: 'ar'}}, {from: c.at(3), cam: 'wide'}, {from: c.at(3) + 90, cam: {x: 420, y: 930, z: 2.2}}];
  return <><Stage ctx={c} f={f} bg="dharamshala_dawn" grade={GRADE.dawn} actors={actors} shots={shots}
    under={<Footprints pts={prints} f={f} from={0} every={0} color="rgba(30,40,55,0.8)" />} over={<Fog f={f} k={0.12} />} /><Black o={fadeEdges(f, c.total, 20, 30)} /></>;
};

// ---------- 20. the portrait ----------
const s20: SceneFn = (f, c) => {
  const a = travel(f, 0, c.at(1) - 10, 2200, 1480); const k = travel(f, 0, c.at(1), 2450, 1740);
  const look = f > c.at(5) + 60 ? kf(f, [[c.at(5) + 60, 0], [c.at(5) + 75, 0.9]]) : 0;
  const actors: Actor[] = [
    {L: ARJUN, uid: 'ar', speaker: 'ARJUN', pose: {y: G, scale: S, ...a, ...sw(a), face: -1, fear: f > c.at(2) + 40 ? 0.8 : 0, lookX: f > c.at(2) ? 1 : 0}},
    {L: KABIR, uid: 'kb', pose: {y: G, scale: S, ...k, ...sw(k), face: -1, fear: f > c.at(2) + 40 ? 1 : 0.2, lookX: f > c.at(2) ? 1 : 0, shake: f > c.at(3) ? f : 0}},
  ];
  const portraitPose = basePose({lookX: -look, smile: look * 0.6, brow: 0.2});
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(1), cam: {on: 'ar'}}, {from: c.at(2) + 50, cam: {x: 1150, y: 420, z: 1.8}}, {from: c.at(3), cam: {x: 1150, y: 420, z: 2.3}},
    {from: c.at(4), cam: {on: 'ar', z: 2}}, {from: c.at(5), cam: {x: 1150, y: 420, z: 2.6}}];
  return <><Stage ctx={c} f={f} bg="chai_stall_morning" grade={GRADE.day} actors={actors} shots={shots}
    under={<Portrait x={1150} y={420} w={190} L={KAKA} p={portraitPose} f={f} />} over={<Dust f={f} n={25} />} /><Black o={fadeEdges(f, c.total, 20, 40)} /></>;
};

// ---------- 21. the city ----------
const s21: SceneFn = (f, c) => {
  if (f >= c.at(1) && f < c.at(2)) {
    return <><CameraLCD f={f} label="IMG_0701.JPG">
      <PhotoContent bg="dharamshala_dawn" w={1460} h={800} people={[
        {L: KESAR, uid: 'pk', p: basePose({x: 960, y: 1000, scale: 0.75, armL: {sh: 10, el: 10, hand: 'claw'}, armR: {sh: -10, el: -10, hand: 'claw'}, faceless: true})},
        {L: ARJUN, uid: 'pa', p: basePose({x: 760, y: 1080, scale: 0.72, smile: 1})},
        {L: KABIR, uid: 'pb', p: basePose({x: 1160, y: 1080, scale: 0.72, smile: 1, armL: {sh: 60, el: 40, hand: 'point'}})},
      ]} />
    </CameraLCD></>;
  }
  const appear = kf(f, [[c.at(2) + 20, 0], [c.at(3) - 5, 0.9]]);
  const scare = f >= c.at(3);
  const actors: Actor[] = [
    {L: KESAR, uid: 'ke', speaker: 'KESAR', pose: {x: 420, y: G, scale: 0.7, alpha: appear, faceless: !scare, armL: {sh: 30, el: 40, hand: 'claw'}, armR: {sh: -40, el: -60, hand: 'claw'}}},
    {L: ARJUN, uid: 'ar', pose: {x: 1100, y: G, scale: 0.7, face: 1, fear: f > c.at(2) ? 0.9 : 0.2, lookX: f > c.at(2) + 40 ? -1 : 0.6, shake: f > c.at(2) + 40 ? f : 0}},
  ];
  const shots: Shot[] = [{from: 0, cam: 'wide'}, {from: c.at(2), cam: {on: 'ar', z: 1.6}}, {from: c.at(3), cam: {on: 'ke', z: 3.0, dy: 20}}];
  return <><Stage ctx={c} f={f} bg="city_room_night" grade={GRADE.deep} actors={actors} shots={shots} shake={scare ? 14 : 0}
    over={<Flash f={f} at={[c.at(3)]} />} /><Black o={Math.max(fadeEdges(f, c.total, 15, 1), kf(f, [[c.at(3) + 45, 0], [c.at(3) + 47, 1]], false))} /></>;
};

// ---------- 22. outro ----------
const s22: SceneFn = (f, c) => (
  <AbsoluteFill style={{background: '#000', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 30}}>
    <div style={{fontFamily: "'Creepster', serif", fontWeight: 400, fontSize: 130, color: '#d8d8d8', opacity: kf(f, [[0, 0], [25, 1]])}}>Kya aap jawab dete?</div>
    <div style={{fontFamily: "'Noto Sans Devanagari', sans-serif", fontWeight: 700, fontSize: 54, color: '#b3121b', opacity: kf(f, [[c.at(0) + 90, 0], [c.at(0) + 110, 1]])}}>Comment mein batao · Subscribe karo</div>
    <Black o={kf(f, [[c.total - 30, 0], [c.total, 1]])} />
  </AbsoluteFill>
);

export const SCENES: Record<string, SceneFn> = {
  s01_coldopen: s01, s02_title: s02, s03_bus: s03, s04_street: s04, s05_chai: s05, s06_flashback: s06, s07_flashback_water: s07,
  s08_warning: s08, s09_dharamshala: s09, s10_path: s10, s11_baoli_top: s11, s12_steps: s12, s13_water: s13, s14_camera: s14,
  s15_separated: s15, s16_hand: s16, s17_rising: s17, s18_kaka_top: s18, s19_dawn: s19, s20_photo: s20, s21_city: s21, s22_outro: s22,
};
