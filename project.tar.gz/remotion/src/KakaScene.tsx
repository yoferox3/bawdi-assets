import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, random} from 'remotion';
import '@fontsource/noto-sans-devanagari/700.css';
import {Kaka, KakaPose} from './Kaka';
import {kf, noise, blinkAt, talkOpen} from './rig';

const KX = 1360;
const TALK: [number, number][] = [[70, 96], [110, 160], [182, 236]];
const SUBS: [number, number, string][] = [
  [62, 106, 'बेटा...'], [106, 176, 'बेटा... आज अमावस है।'], [176, 270, 'वहाँ मत जाना।'],
];

const kakaPose = (f: number): KakaPose => {
  const decay = (t0: number) => (f < t0 ? 0 : Math.exp(-(f - t0) / 35));
  const wag = f > 195 && f < 240 ? Math.sin((f - 195) * 0.7) * 14 : 0;
  return {
    breathe: Math.sin(f / 30 * Math.PI * 0.6),
    headRot: (noise('trem', f, 0.5) - 0.5) * 2.4 + kf(f, [[0, 0], [110, 0], [125, -4], [150, -4], [165, 0], [182, 3], [236, 3], [250, 0]])
      + talkOpen(f, TALK, 'nod') * 2,
    headTurn: kf(f, [[0, 0.15], [112, 0.15], [124, -0.7], [150, -0.7], [164, 0.15]]),
    headDip: kf(f, [[0, 0], [176, 0], [196, 12], [240, 12], [262, 0]]),
    lookX: kf(f, [[0, 0.2], [112, 0.2], [120, -1], [150, -1], [160, 0.1]]),
    lookY: kf(f, [[0, 0], [176, 0], [190, 0.4], [240, 0.4], [255, 0]]),
    blink: blinkAt(f, [20, 100, 168, 262]),
    brow: kf(f, [[0, -0.3], [60, -0.3], [70, -0.7], [176, -0.7], [186, 1], [236, 1], [252, -0.5]]),
    mouth: talkOpen(f, TALK),
    armA: {sh: kf(f, [[0, 8], [182, 8], [198, 42], [242, 42], [262, 8]]),
      el: kf(f, [[0, 12], [182, 12], [198, 112], [242, 112], [262, 12]]) + wag,
      hand: f > 186 && f < 258 ? 'point' : 'open'},
    armB: {sh: kf(f, [[0, -8], [28, -8], [56, -95]]), el: kf(f, [[0, -22], [28, -22], [56, -55]])},
    swing: (f > 28 && f < 56 ? 8 : 0) + Math.sin((f - 56) * 0.22) * 16 * decay(56) + (noise('sw', f, 0.08) - 0.5) * 4,
    flame: noise('fl', f, 0.7) * 0.8 + (random('sp' + Math.floor(f / 2)) > 0.9 ? 0.2 : 0),
  };
};

export const KakaScene: React.FC<{bg: string}> = ({bg}) => {
  const f = useCurrentFrame();
  const p = kakaPose(f);
  const zoom = 1 + kf(f, [[0, 0], [300, 0.06]]);
  const lanternUp = kf(f, [[0, 0], [28, 0], [56, 1]]);
  const glow = 0.7 + 0.3 * p.flame;
  // lantern position in screen px (follows the arm raise)
  const lx = KX + kf(f, [[0, 0], [28, 0], [56, 1]]) * 150 + 110;
  const ly = 1040 - 560 - lanternUp * 270;
  const sub = SUBS.find(([a, b]) => f >= a && f < b);
  return (
    <AbsoluteFill style={{background: '#05070c', overflow: 'hidden'}}>
      <AbsoluteFill style={{transform: `scale(${zoom})`, transformOrigin: '70% 60%'}}>
        <Img src={staticFile(bg)} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${1 + (zoom - 1) * 0.5})`}} />
        {/* night grade so the flat character sits in the painted scene */}
        <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(40,10,30,0.18), rgba(10,5,20,0.35))'}} />
        <svg width={1920} height={1080} style={{position: 'absolute'}}>
          <ellipse cx={KX} cy={1036} rx={170} ry={22} fill="rgba(0,0,0,0.45)" />
          <g transform={`translate(${KX},1040) scale(0.8)`}><Kaka p={p} /></g>
        </svg>
        <div style={{position: 'absolute', left: lx - 420, top: ly - 420, width: 840, height: 840, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,175,70,0.55) 0%, rgba(255,140,40,0.18) 35%, rgba(0,0,0,0) 68%)',
          mixBlendMode: 'screen', opacity: glow}} />
        {Array.from({length: 3}).map((_, i) => (
          <div key={i} style={{position: 'absolute', left: -600 + ((f * (0.6 + i * 0.3) + i * 700) % 2600), top: 620 + i * 90, width: 1400, height: 380,
            borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(200,210,230,0.14), rgba(0,0,0,0) 70%)', filter: 'blur(20px)'}} />
        ))}
      </AbsoluteFill>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 45% 50%, rgba(0,0,0,0) 45%, rgba(0,0,0,0.8) 100%)'}} />
      <AbsoluteFill style={{opacity: 0.07, mixBlendMode: 'overlay'}}>
        <svg width="1920" height="1080"><filter id="g"><feTurbulence type="fractalNoise" baseFrequency="0.9" seed={f % 20} /></filter>
          <rect width="1920" height="1080" filter="url(#g)" /></svg>
      </AbsoluteFill>
      {sub && <div style={{position: 'absolute', bottom: 56, width: '100%', textAlign: 'center', fontFamily: "'Noto Sans Devanagari'",
        fontSize: 54, fontWeight: 700, color: '#fff', textShadow: '0 0 10px #000, 0 3px 4px #000'}}>{sub[2]}</div>}
    </AbsoluteFill>
  );
};
