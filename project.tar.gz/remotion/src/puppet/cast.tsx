import React from 'react';
import {Look, INK} from './Person';

const st = (w = 6) => ({stroke: INK, strokeWidth: w, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const});
const torsoPath = (w: number, hem = -372) =>
  `M${-88 * w},-772 C${-104 * w},-700 ${-110 * w},-560 ${-118 * w},${hem} L${118 * w},${hem} C${110 * w},-560 ${104 * w},-700 ${88 * w},-772 C${40 * w},-790 ${-40 * w},-790 ${-88 * w},-772 Z`;

export const KAKA: Look = {
  name: 'kaka', skin: '#8b5434', skinDk: '#6a3a20', skinLt: '#a0663f', height: 1, width: 1, headScale: 1.32,
  sleeve: '#f2eee4', sleeveDk: '#cfc5b0', legs: 'dhoti', pant: '#f2eee4', pantDk: '#d6cdb9',
  shoe: 'mojari', shoeCol: '#6b3f1c', shoeCol2: '#d9a441', eyes: 'cloudy', hair: 'pagdi', hairCol: '#f4f4f0', moustache: true,
  torso: (w) => (
    <g>
      <path d={torsoPath(w)} fill="#f2eee4" {...st()} />
      <path d={`M${70 * w},-740 C${82 * w},-620 ${88 * w},-500 ${92 * w},-380`} stroke="#cfc5b0" strokeWidth={16} fill="none" />
      <path d="M-26,-782 L0,-744 L26,-782" fill="none" {...st(4)} />
      <path d="M0,-744 L0,-600" stroke={INK} strokeWidth={3.5} />
      {[-720, -680, -640].map((y) => <circle key={y} cx={8} cy={y} r={4} fill="#cfc5b0" stroke={INK} strokeWidth={2} />)}
      <path d="M-92,-770 C-60,-790 -30,-784 -14,-770 C10,-700 40,-600 70,-470 L30,-452 C10,-560 -30,-660 -70,-720 C-84,-700 -98,-640 -104,-560 L-116,-560 C-110,-660 -104,-730 -92,-770 Z" fill="#7a1f24" {...st()} />
      <path d="M-40,-760 C-10,-680 20,-590 50,-470" stroke="#5a1418" strokeWidth={8} fill="none" />
      <path d="M36,-440 l4,14 M48,-446 l4,14 M60,-452 l4,14" stroke="#d9a441" strokeWidth={4} />
    </g>
  ),
};

export const ARJUN: Look = {
  name: 'arjun', skin: '#b5774f', skinDk: '#93593a', skinLt: '#c88a60', height: 1.04, width: 0.98, headScale: 1.26,
  sleeve: '#b59a6e', sleeveDk: '#8f7750', cuff: '#a08660', legs: 'pants', pant: '#3b4a68', pantDk: '#2b3750',
  shoe: 'boot', shoeCol: '#6a4423', eyes: 'dark', hair: 'arjun', hairCol: '#16161c', stubble: true, backpack: true,
  torso: (w) => (
    <g>
      <path d={torsoPath(w, -400)} fill="#f4f4f2" {...st()} />
      {/* open utility jacket */}
      <path d={`M${-88 * w},-772 C${-104 * w},-700 ${-110 * w},-560 ${-120 * w},-390 L${-34 * w},-390 L${-26 * w},-700 L-30,-782 Z`} fill="#b59a6e" {...st()} />
      <path d={`M${88 * w},-772 C${104 * w},-700 ${110 * w},-560 ${120 * w},-390 L${34 * w},-390 L${26 * w},-700 L30,-782 Z`} fill="#b59a6e" {...st()} />
      <rect x={-96 * w} y={-640} width={44} height={40} rx={4} fill="#a08660" {...st(4)} />
      <rect x={52 * w} y={-640} width={44} height={40} rx={4} fill="#a08660" {...st(4)} />
      <path d="M-30,-782 L-48,-730 L-26,-700 M30,-782 L48,-730 L26,-700" fill="none" {...st(4)} />
      {/* backpack straps + camera on its strap */}
      <path d={`M${-70 * w},-770 L${-74 * w},-520 M${70 * w},-770 L${74 * w},-520`} stroke="#374151" strokeWidth={14} />
      <path d="M-40,-776 L0,-600 L40,-776" stroke="#222" strokeWidth={6} fill="none" />
      <g transform="translate(0,-570) scale(0.9)">
        <rect x={-46} y={-30} width={92} height={60} rx={10} fill="#25272c" {...st(5)} />
        <circle cx={6} cy={2} r={22} fill="#3d424c" {...st(5)} /><circle cx={6} cy={2} r={12} fill="#11151c" /><circle cx={1} cy={-3} r={4} fill="#9fc3e0" />
      </g>
      <path d={`M${-118 * w},-400 L${118 * w},-400 L${116 * w},-372 L${-116 * w},-372 Z`} fill="#2b3750" {...st(5)} />
    </g>
  ),
};

export const KABIR: Look = {
  name: 'kabir', skin: '#c48a5e', skinDk: '#a06c44', skinLt: '#d49c70', height: 0.93, width: 1.18, headScale: 1.34,
  sleeve: '#e8892b', sleeveDk: '#c26c1a', cuff: '#c26c1a', legs: 'pants', pant: '#8a7a56', pantDk: '#6c5e40',
  shoe: 'sneaker', shoeCol: '#f2f2f2', shoeCol2: '#c0392b', eyes: 'dark', hair: 'kabir', hairCol: '#2a1b12', glasses: true,
  torso: (w) => (
    <g>
      <path d={torsoPath(w, -380)} fill="#e8892b" {...st()} />
      <path d="M-70,-790 C-60,-830 60,-830 70,-790 C40,-770 -40,-770 -70,-790 Z" fill="#c26c1a" {...st(5)} />
      <path d="M-14,-776 L-18,-690 M14,-776 L18,-690" stroke="#f4f4f2" strokeWidth={5} />
      <path d={`M${-70 * w},-520 L${70 * w},-520 L${60 * w},-440 L${-60 * w},-440 Z`} fill="#c26c1a" {...st(5)} />
      <path d={`M${-112 * w},-400 L${112 * w},-400`} stroke="#c26c1a" strokeWidth={14} />
      <path d="M-34,-570 C-34,-650 34,-650 34,-570 L34,-540 L24,-550 L12,-538 L0,-550 L-12,-538 L-24,-550 L-34,-540 Z" fill="#fff4dc" stroke={INK} strokeWidth={3} />
      <circle cx={-12} cy={-594} r={5} fill={INK} /><circle cx={12} cy={-594} r={5} fill={INK} />
    </g>
  ),
};

const kesarTorso = (skin: string) => (w: number) => (
  <g>
    <path d={`M${-70 * w},-772 C${-84 * w},-700 ${-96 * w},-560 ${-110 * w},-420 L${110 * w},-420 C${96 * w},-560 ${84 * w},-700 ${70 * w},-772 C${30 * w},-786 ${-30 * w},-786 ${-70 * w},-772 Z`} fill={skin} {...st()} />
    <path d={`M${-74 * w},-760 C${-60 * w},-700 ${-60 * w},-660 ${-70 * w},-620 L${70 * w},-620 C${60 * w},-660 ${60 * w},-700 ${74 * w},-760 C${20 * w},-740 ${-20 * w},-740 ${-74 * w},-760 Z`} fill="#7a0d15" {...st(5)} />
    <path d={`M${60 * w},-780 C${20 * w},-700 ${-60 * w},-560 ${-112 * w},-430 L${-60 * w},-420 C${-10 * w},-540 ${50 * w},-640 ${90 * w},-720 Z`} fill="#a3121d" {...st()} />
    <path d={`M${40 * w},-740 C${0},-660 ${-50 * w},-560 ${-90 * w},-440`} stroke="#d9a441" strokeWidth={6} fill="none" />
    <path d={`M${-110 * w},-420 L${110 * w},-420`} stroke="#6e0b12" strokeWidth={10} />
  </g>
);

export const KESAR: Look = {
  name: 'kesar', skin: '#b9c4c6', skinDk: '#8e9ca0', skinLt: '#cdd6d8', height: 1.0, width: 0.86, headScale: 1.22,
  sleeve: '#a3121d', sleeveDk: '#7a0d15', legs: 'saree', pant: '#a3121d', pantDk: '#6e0b12',
  shoe: 'none', shoeCol: '#000', eyes: 'ghost', hair: 'kesar', hairCol: '#0d0f14',
  torso: kesarTorso('#b9c4c6'),
};

export const KESAR_ALIVE: Look = {...KESAR, skin: '#c58c62', skinDk: '#a06c44', skinLt: '#d49c70', eyes: 'dark', torso: kesarTorso('#c58c62')};
