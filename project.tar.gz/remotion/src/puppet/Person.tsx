import React from 'react';

// Shared cut-out puppet rig. Flat colours + thick ink outlines.
// Local coords: origin between the feet on the ground, up is -y.

export const INK = '#1b1310';
const st = (w = 6) => ({stroke: INK, strokeWidth: w, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const});

export type Hand = 'open' | 'point' | 'fist' | 'claw';
export type Prop = 'none' | 'lantern' | 'torch' | 'camera' | 'phone' | 'glass';
export type ArmPose = {sh: number; el: number; hand: Hand; prop?: Prop};
export type LegPose = {hip: number; knee: number};

export type Pose = {
  x: number; y: number; scale: number; face: 1 | -1;  // placement; face=-1 mirrors the puppet
  bob: number; lean: number; breathe: number; shake: number;
  headRot: number; headTurn: number; headDip: number;
  lookX: number; lookY: number; blink: number; brow: number; mouth: number; smile: number; fear: number;
  armL: ArmPose; armR: ArmPose; legL: LegPose; legR: LegPose;
  swing: number; flame: number; torchOn: number; hairWave: number; alpha: number; faceless?: boolean;
  rot: number; tint: number; // rot: whole-body rotation around the feet; tint: 0 normal .. 1 black silhouette
};

export const basePose = (o: Partial<Pose> = {}): Pose => ({
  x: 960, y: 1040, scale: 0.8, face: 1, bob: 0, lean: 0, breathe: 0, shake: 0,
  headRot: 0, headTurn: 0, headDip: 0, lookX: 0, lookY: 0, blink: 0, brow: 0, mouth: 0, smile: 0, fear: 0,
  armL: {sh: 8, el: 10, hand: 'open'}, armR: {sh: -8, el: -10, hand: 'open'},
  legL: {hip: 2, knee: 0}, legR: {hip: -2, knee: 0},
  swing: 0, flame: 0.5, torchOn: 0, hairWave: 0, alpha: 1, rot: 0, tint: 0, ...o,
});

export type Look = {
  name: string;
  skin: string; skinDk: string; skinLt: string;
  height: number;            // overall scale multiplier
  width: number;             // torso width multiplier
  headScale: number;
  sleeve: string; sleeveDk: string; cuff?: string;
  legs: 'pants' | 'dhoti' | 'saree';
  pant: string; pantDk: string;
  shoe: 'mojari' | 'boot' | 'sneaker' | 'none';
  shoeCol: string; shoeCol2?: string;
  eyes: 'cloudy' | 'dark' | 'ghost';
  hair: 'pagdi' | 'arjun' | 'kabir' | 'kesar';
  hairCol: string;
  moustache?: boolean; stubble?: boolean; glasses?: boolean;
  torso: (w: number, b: number) => React.ReactNode;   // draws clothing over the chest
  backpack?: boolean;
};

// ---------- small parts ----------
const HandShape: React.FC<{kind: Hand; skin: string; claw?: boolean}> = ({kind, skin}) => (
  <g>
    {kind === 'point' && <path d="M-7,26 L-8,82 Q0,90 8,82 L7,26 Z" fill={skin} {...st()} />}
    {(kind === 'open' || kind === 'claw') && <>
      <path d={kind === 'claw' ? 'M-20,10 L-30,70 L-24,82 L-12,16' : 'M-20,10 L-24,48 Q-18,54 -13,48 L-10,14'} fill={skin} {...st()} />
      <path d={kind === 'claw' ? 'M-8,14 L-10,90 L-2,100 L4,16' : 'M-8,14 L-8,58 Q-1,64 5,58 L4,14'} fill={skin} {...st()} />
      <path d={kind === 'claw' ? 'M6,12 L14,84 L22,90 L16,10' : 'M6,12 L10,52 Q17,57 21,50 L16,10'} fill={skin} {...st()} />
    </>}
    <ellipse cx={0} cy={14} rx={22} ry={24} fill={skin} {...st()} />
    {(kind === 'fist' || kind === 'point') && <path d="M-16,4 Q0,-2 16,4 M-17,16 Q0,10 17,16" fill="none" stroke={INK} strokeWidth={3} />}
    <path d="M18,0 Q32,10 24,28" fill={skin} {...st()} />
  </g>
);

const Lantern: React.FC<{flame: number}> = ({flame}) => (
  <g transform="scale(1.35)">
    <path d="M-26,8 Q0,-34 26,8" fill="none" stroke="#7e5a18" strokeWidth={7} />
    <rect x={-30} y={8} width={60} height={18} rx={6} fill="#b8892e" {...st()} />
    <path d="M-28,26 Q-46,70 -28,112 L28,112 Q46,70 28,26 Z" fill={`rgba(255,${200 + flame * 40},120,0.92)`} {...st()} />
    <path d="M0,96 Q-12,76 0,50 Q12,76 0,96 Z" fill="#fff6c8" transform={`translate(0,96) scale(${0.85 + flame * 0.3}) translate(0,-96)`} />
    <path d="M-30,30 L-30,110 M30,30 L30,110" stroke="#7e5a18" strokeWidth={6} />
    <rect x={-36} y={110} width={72} height={20} rx={6} fill="#b8892e" {...st()} />
  </g>
);

// Torch held in the fist; lens at +x. The caller turns it so it always points the way the character faces.
const Torch: React.FC<{on: number}> = ({on}) => (
  <g>
    {on > 0 && <>
      <path d="M82,-14 L640,-190 L640,190 L82,14 Z" fill="rgba(255,248,200,0.16)" style={{mixBlendMode: 'screen'}} />
      <path d="M82,-8 L420,-70 L420,70 L82,8 Z" fill="rgba(255,250,215,0.14)" style={{mixBlendMode: 'screen'}} />
      <circle cx={84} cy={0} r={22} fill="rgba(255,250,220,0.5)" />
    </>}
    <rect x={-40} y={-13} width={100} height={26} rx={6} fill="#2c2f36" {...st(5)} />
    <rect x={56} y={-19} width={24} height={38} rx={4} fill="#4a4f5a" {...st(5)} />
    <ellipse cx={80} cy={0} rx={5} ry={16} fill={on > 0 ? '#fffbe0' : '#888'} />
  </g>
);

const Camera: React.FC = () => (
  <g>
    <rect x={-46} y={-30} width={92} height={60} rx={10} fill="#25272c" {...st(5)} />
    <rect x={-30} y={-40} width={30} height={12} rx={3} fill="#25272c" {...st(4)} />
    <circle cx={6} cy={2} r={22} fill="#3d424c" {...st(5)} />
    <circle cx={6} cy={2} r={12} fill="#11151c" />
    <circle cx={1} cy={-3} r={4} fill="#9fc3e0" />
  </g>
);

const Phone: React.FC = () => (
  <g><rect x={-16} y={-30} width={32} height={58} rx={6} fill="#1d1f24" {...st(4)} /><rect x={-11} y={-24} width={22} height={44} rx={2} fill="#7fb2ff" /></g>
);

const Glass: React.FC = () => (
  <g><path d="M-14,-30 L14,-30 L11,10 L-11,10 Z" fill="rgba(200,140,80,0.9)" {...st(4)} /><path d="M-12,-20 L12,-20" stroke="#f3e3c7" strokeWidth={4} /></g>
);

const PropShape: React.FC<{prop?: Prop; p: Pose; total: number}> = ({prop, p, total}) => {
  if (!prop || prop === 'none') return null;
  if (prop === 'lantern') return <g transform={`rotate(${-total + p.swing})`}><g transform="translate(0,30)"><Lantern flame={p.flame} /></g></g>;
  if (prop === 'torch') return <g transform={`translate(0,26) rotate(${-total + 6})`}><Torch on={p.torchOn} /></g>;
  if (prop === 'camera') return <g transform={`translate(0,40) rotate(${-total})`}><Camera /></g>;
  if (prop === 'phone') return <g transform={`translate(0,40) rotate(${-total})`}><Phone /></g>;
  return <g transform={`translate(0,38) rotate(${-total})`}><Glass /></g>;
};

// Arm: shoulder at (0,0), hangs +y. el is relative to the upper arm.
const Arm: React.FC<{a: ArmPose; L: Look; p: Pose; parentRot: number}> = ({a, L, p, parentRot}) => {
  const total = parentRot + a.sh + a.el;
  const thin = L.name === 'kesar';
  return (
    <g transform={`rotate(${a.sh})`}>
      <path d={thin ? 'M-16,-8 Q-20,95 -16,186 L16,186 Q20,95 16,-8 Z' : 'M-28,-8 Q-34,95 -26,186 L26,186 Q34,95 28,-8 Q0,-24 -28,-8 Z'}
        fill={thin ? L.skin : L.sleeve} {...st()} />
      {!thin && <path d="M-14,20 Q-20,100 -14,180" fill="none" stroke={L.sleeveDk} strokeWidth={10} />}
      <g transform={`translate(0,180) rotate(${a.el})`}>
        <path d={thin ? 'M-15,-4 L-12,150 L12,150 L15,-4 Z' : 'M-25,-4 L-22,150 L22,150 L25,-4 Z'} fill={thin ? L.skin : L.sleeve} {...st()} />
        {L.cuff && <path d="M-23,132 L23,132 L22,150 L-22,150 Z" fill={L.cuff} {...st(3)} />}
        <g transform="translate(0,152)">
          {a.prop === 'lantern' && <PropShape prop={a.prop} p={p} total={total} />}
          <HandShape kind={a.hand} skin={L.skin} />
          {a.prop && a.prop !== 'lantern' && <PropShape prop={a.prop} p={p} total={total} />}
        </g>
      </g>
    </g>
  );
};

// Shoe: origin at the ankle on the ground, toe points +x
const Shoe: React.FC<{L: Look}> = ({L}) => {
  if (L.shoe === 'none') return null;
  if (L.shoe === 'mojari') return (
    <g>
      <path d="M-22,-24 C-30,-8 -28,4 -18,8 L36,8 C52,8 62,2 66,-10 C68,-18 64,-26 58,-28 C60,-18 54,-12 44,-14 C30,-16 14,-22 4,-28 Z" fill={L.shoeCol} {...st(5)} />
      <path d="M-8,-20 C8,-14 24,-10 40,-10" stroke={L.shoeCol2 || '#d9a441'} strokeWidth={4} fill="none" />
      <path d="M-20,6 L38,6" stroke="#2e1d0e" strokeWidth={4} />
    </g>
  );
  if (L.shoe === 'boot') return (
    <g>
      <path d="M-24,-44 L-24,-6 C-24,4 -18,8 -10,8 L44,8 C56,8 60,0 56,-8 C52,-16 40,-20 24,-22 L18,-44 Z" fill={L.shoeCol} {...st(5)} />
      <path d="M-24,2 L56,2" stroke="#2a1a0c" strokeWidth={6} />
      <path d="M-6,-38 L12,-36 M-4,-28 L16,-26" stroke={L.shoeCol2 || '#c9a36a'} strokeWidth={3} />
    </g>
  );
  return (
    <g>
      <path d="M-24,-30 L-24,-4 C-24,4 -18,8 -10,8 L46,8 C58,8 62,-2 56,-10 C48,-18 32,-20 18,-24 L14,-32 Z" fill={L.shoeCol} {...st(5)} />
      <path d="M-24,0 L58,0" stroke={L.shoeCol2 || '#c0392b'} strokeWidth={7} />
      <path d="M-2,-26 L12,-20 M2,-18 L18,-14" stroke="#888" strokeWidth={3} />
    </g>
  );
};

// Leg: hip at (0,0); thigh 220, shin 200; foot stays flat on the ground.
const Leg: React.FC<{l: LegPose; L: Look; side: -1 | 1}> = ({l, L, side}) => {
  const baggy = L.legs === 'dhoti';
  return (
    <g transform={`rotate(${l.hip})`}>
      <path d={baggy ? 'M-50,-10 Q-62,110 -44,222 L44,222 Q62,110 50,-10 Z' : 'M-36,-10 Q-40,110 -32,222 L32,222 Q40,110 36,-10 Z'} fill={L.pant} {...st()} />
      <path d={`M${side * 20},10 Q${side * 26},110 ${side * 18},210`} stroke={L.pantDk} strokeWidth={baggy ? 10 : 7} fill="none" />
      <g transform={`translate(0,214) rotate(${l.knee})`}>
        <path d={baggy ? 'M-44,-6 Q-46,100 -34,196 L34,196 Q46,100 44,-6 Z' : 'M-32,-6 Q-33,100 -28,196 L28,196 Q33,100 32,-6 Z'} fill={L.pant} {...st()} />
        {baggy && <path d="M-34,180 Q0,192 34,180" stroke={L.pantDk} strokeWidth={5} fill="none" />}
        {L.shoe === 'mojari' && <path d="M-14,190 L-14,206 L14,206 L14,190 Z" fill={L.skinDk} {...st(4)} />}
        <g transform={`translate(0,206) rotate(${-(l.hip + l.knee)}) scale(${side * 1.35},1.35)`}><Shoe L={L} /></g>
      </g>
    </g>
  );
};

// ---------- head ----------
const Eye: React.FC<{x: number; side: number; p: Pose; L: Look; id: string}> = ({x, side, p, L, id}) => {
  const hood = L.eyes === 'cloudy' ? 0.32 : 0.08;
  const ry = 10 + p.fear * 4;
  const lid = Math.min(1, hood * (1 - p.fear) + p.blink * (1 - hood));
  const ex = x + p.headTurn * 6;
  const iris = L.eyes === 'cloudy' ? '#aab9bf' : L.eyes === 'ghost' ? '#0a0a0a' : '#4a2c18';
  const pupil = L.eyes === 'cloudy' ? '#7c8c92' : '#050505';
  return (
    <g>
      <clipPath id={id}><ellipse cx={ex} cy={-118} rx={17} ry={ry} /></clipPath>
      <ellipse cx={ex} cy={-118} rx={17} ry={ry} fill={L.eyes === 'ghost' ? '#101010' : '#eef2f3'} />
      <g clipPath={`url(#${id})`}>
        {L.eyes !== 'ghost' && <>
          <circle cx={ex + p.lookX * 7} cy={-117 + p.lookY * 3} r={L.eyes === 'cloudy' ? 8 : 7 - p.fear * 2} fill={iris} />
          <circle cx={ex + p.lookX * 7} cy={-117 + p.lookY * 3} r={L.eyes === 'cloudy' ? 3.5 : 4 - p.fear * 2} fill={pupil} />
          <circle cx={ex + p.lookX * 7 - 3} cy={-120 + p.lookY * 3} r={2} fill="#fff" />
        </>}
        {L.eyes === 'ghost' && <circle cx={ex + p.lookX * 5} cy={-118} r={2.5} fill="#f4f4f4" />}
        <rect x={ex - 20} y={-118 - ry - 2} width={40} height={(2 * ry + 4) * lid} fill={L.skin} />
      </g>
      <ellipse cx={ex} cy={-118} rx={17} ry={ry} fill="none" stroke={INK} strokeWidth={3.5} />
      <path d={`M${ex - 18},${-116 - ry + (2 * ry) * lid} Q${ex},${-119 - ry + (2 * ry) * lid} ${ex + 18},${-116 - ry + (2 * ry) * lid}`} fill="none" stroke={INK} strokeWidth={4} />
      {L.eyes === 'cloudy' && <path d={`M${ex + side * 20},-122 l${side * 9},-4 M${ex + side * 20},-116 l${side * 10},1`} stroke={L.skinDk} strokeWidth={2.5} />}
      {L.eyes === 'ghost' && <path d={`M${ex - 16},-104 Q${ex},-96 ${ex + 16},-104`} stroke="#5d6b78" strokeWidth={5} fill="none" />}
    </g>
  );
};

const HairBack: React.FC<{L: Look; p: Pose}> = ({L, p}) => {
  if (L.hair !== 'kesar') return null;
  const w = p.hairWave;
  return <path d={`M-70,-200 C-110,-120 ${-110 + w * 10},40 ${-90 + w * 16},240 L${90 + w * 16},240 C${110 + w * 10},40 110,-120 70,-200 Z`} fill={L.hairCol} {...st(5)} />;
};

const HairFront: React.FC<{L: Look; p: Pose}> = ({L, p}) => {
  const ink = st(4.5);
  if (L.hair === 'pagdi') return (
    <g>
      <path d="M-96,-176 C-120,-214 -104,-262 -60,-280 C-20,-296 30,-296 66,-282 C110,-262 122,-214 98,-176 Q0,-150 -96,-176 Z" fill="#f5f2ea" {...st()} />
      <path d="M-100,-186 Q-20,-150 104,-196 M-108,-214 Q-10,-172 110,-232 M-96,-248 Q0,-206 92,-262 M-60,-276 Q10,-244 50,-288" stroke="#d4ccba" strokeWidth={9} fill="none" />
      <path d="M-100,-186 Q-20,-150 104,-196 M-108,-214 Q-10,-172 110,-232 M-96,-248 Q0,-206 92,-262" stroke={INK} strokeWidth={3} fill="none" />
      <path d="M-70,-160 Q0,-140 70,-160 L74,-180 Q0,-160 -74,-180 Z" fill="#d4ccba" {...st(4)} />
      <path d="M96,-200 Q130,-170 118,-120 Q112,-100 100,-96 Q110,-140 88,-176 Z" fill="#f5f2ea" {...ink} />
    </g>
  );
  if (L.hair === 'arjun') return (
    <g>
      <path d="M-68,-140 C-80,-200 -50,-238 -4,-236 C44,-240 80,-208 70,-146 C66,-162 58,-172 48,-174 C40,-192 18,-196 4,-186 C-8,-200 -34,-196 -42,-180 C-54,-180 -64,-162 -68,-140 Z" fill={L.hairCol} {...ink} />
      <path d="M-40,-214 Q-20,-226 6,-222 M14,-218 Q40,-222 56,-204" stroke="#3a3a46" strokeWidth={4} fill="none" />
      <path d="M-66,-144 L-62,-110 L-56,-140 Z M66,-146 L62,-112 L56,-142 Z" fill={L.hairCol} {...st(3)} />
    </g>
  );
  if (L.hair === 'kabir') return (
    <g>
      {[[-58, -170, 28], [-30, -200, 32], [6, -210, 34], [40, -198, 30], [62, -168, 26], [-10, -180, 30], [28, -178, 28]].map(([x, y, r], i) =>
        <circle key={i} cx={x} cy={y} r={r} fill={L.hairCol} {...st(4.5)} />)}
      <path d="M-62,-160 Q0,-176 64,-158 L60,-150 Q0,-166 -58,-152 Z" fill={L.hairCol} />
    </g>
  );
  // kesar: centre parting, wet strands; covers the face when faceless
  const w = p.hairWave;
  return (
    <g>
      <path d="M-72,-150 C-80,-210 -40,-246 0,-244 C40,-246 80,-210 72,-150 C60,-190 30,-206 0,-200 C-30,-206 -60,-190 -72,-150 Z" fill={L.hairCol} {...ink} />
      <path d={`M-72,-150 C-90,-80 ${-86 + w * 8},40 ${-70 + w * 12},150 L${-50 + w * 12},150 C-58,40 -62,-80 -50,-160 Z`} fill={L.hairCol} {...ink} />
      <path d={`M72,-150 C90,-80 ${86 + w * 8},40 ${70 + w * 12},150 L${50 + w * 12},150 C58,40 62,-80 50,-160 Z`} fill={L.hairCol} {...ink} />
      {p.faceless && <path d={`M-58,-196 C-70,-120 ${-60 + w * 6},-20 ${-40 + w * 10},60 L${40 + w * 10},60 C60,-20 70,-120 58,-196 C30,-210 -30,-210 -58,-196 Z`} fill={L.hairCol} {...ink} />}
      <path d={`M-62,-120 Q${-70 + w * 6},0 ${-60 + w * 10},120 M64,-120 Q${70 + w * 6},0 ${60 + w * 10},120`} stroke="#2a3038" strokeWidth={3} fill="none" />
    </g>
  );
};

const Head: React.FC<{p: Pose; L: Look; uid: string}> = ({p, L, uid}) => {
  const t = p.headTurn * 8;
  const browY = -142 - p.brow * 7 - p.fear * 6;
  const browRot = -p.brow * 6 + p.fear * 8;
  const chubby = L.hair === 'kabir' ? 8 : 0;
  const browCol = L.hair === 'pagdi' ? '#f4f4f0' : L.hairCol;
  return (
    <g>
      <path d="M-24,4 L-22,-50 L22,-50 L24,4 Z" fill={L.skinDk} {...st()} />
      <ellipse cx={-64 - chubby + t * 0.3} cy={-110} rx={12} ry={20} fill={L.skin} {...st()} />
      <ellipse cx={64 + chubby + t * 0.3} cy={-110} rx={12} ry={20} fill={L.skin} {...st()} />
      <path d={`M${-62 - chubby},-172 C${-68 - chubby},-120 ${-64 - chubby},-80 -46,-54 C-30,-36 -15,-30 0,-30 C15,-30 30,-36 46,-54 C${64 + chubby},-80 ${68 + chubby},-120 ${62 + chubby},-172 Z`} fill={L.skin} {...st()} />
      <path d="M38,-160 C52,-120 50,-80 34,-56" fill="none" stroke={L.skinDk} strokeWidth={12} opacity={0.5} />
      <g transform={`translate(${t},0)`}>
        {L.eyes === 'cloudy' && <path d="M-34,-160 Q0,-166 34,-160 M-26,-151 Q0,-156 26,-151 M-20,-78 Q-30,-66 -34,-52 M20,-78 Q30,-66 34,-52" fill="none" stroke={L.skinDk} strokeWidth={3} />}
        {L.stubble && <path d="M-44,-60 C-30,-36 30,-36 44,-60 C40,-44 24,-30 0,-30 C-24,-30 -40,-44 -44,-60 Z" fill={L.skinDk} opacity={0.55} />}
        <Eye x={-27} side={-1} p={p} L={L} id={uid + 'el'} />
        <Eye x={27} side={1} p={p} L={L} id={uid + 'er'} />
        {L.glasses && <g fill="rgba(255,255,255,0.12)" stroke={INK} strokeWidth={5}>
          <rect x={-52} y={-136} width={46} height={36} rx={12} /><rect x={6} y={-136} width={46} height={36} rx={12} /><path d="M-6,-120 L6,-120" fill="none" />
        </g>}
        <g transform={`translate(-28,${browY}) rotate(${browRot})`}>
          <path d="M-24,4 Q-12,-12 22,-2 Q8,4 -4,6 Q-14,10 -24,4 Z" fill={browCol} {...st(3.5)} />
        </g>
        <g transform={`translate(28,${browY}) rotate(${-browRot})`}>
          <path d="M24,4 Q12,-12 -22,-2 Q-8,4 4,6 Q14,10 24,4 Z" fill={browCol} {...st(3.5)} />
        </g>
        <path d="M-4,-108 Q-9,-94 -15,-84 Q-6,-76 0,-80 Q6,-76 15,-84 Q9,-94 4,-108" fill={L.skinLt} stroke={INK} strokeWidth={3.5} strokeLinejoin="round" />
        <g transform="translate(0,-56)">
          {p.mouth < 0.06 && p.smile > 0.1
            ? <path d={`M-18,0 Q0,${6 + p.smile * 10} 18,0`} stroke={INK} strokeWidth={4} fill="none" />
            : <>
              <ellipse cx={0} cy={2 + p.mouth * 6} rx={13 + p.mouth * 4 + p.smile * 4} ry={2 + p.mouth * 12} fill="#3b0e0a" stroke={INK} strokeWidth={3} />
              {p.mouth > 0.25 && <path d={`M-10,${-1 + p.mouth * 2} Q0,${3 + p.mouth * 2} 10,${-1 + p.mouth * 2}`} stroke="#ece3d0" strokeWidth={4} fill="none" />}
            </>}
        </g>
        {L.moustache && <g transform={`translate(0,${-74 - p.mouth * 3})`}>
          <path d="M0,-6 C-20,-14 -46,-8 -62,4 C-72,10 -84,6 -90,-8 C-92,6 -82,22 -64,20 C-44,18 -22,14 0,8 C22,14 44,18 64,20 C82,22 92,6 90,-8 C84,6 72,10 62,4 C46,-8 20,-14 0,-6 Z" fill="#f4f4f0" {...st(4.5)} />
          <path d="M-12,0 Q-34,4 -54,10 M12,0 Q34,4 54,10" stroke="#c9c9c4" strokeWidth={3} fill="none" />
        </g>}
      </g>
      <HairFront L={L} p={p} />
    </g>
  );
};

// ---------- whole person ----------
export const Person: React.FC<{p: Pose; L: Look; uid: string}> = ({p, L, uid}) => {
  const br = 1 + p.breathe * 0.012;
  const w = L.width;
  const sx = (n: number) => n * w;
  const shake = p.shake ? Math.sin(p.shake * 9.7) * 3 * Math.min(1, Math.abs(p.shake)) : 0;
  return (
    <g opacity={p.alpha} style={p.tint ? {filter: `brightness(${1 - p.tint * 0.88})`} : undefined} transform={`translate(${p.x + shake},${p.y + p.bob}) rotate(${p.rot}) scale(${p.scale * L.height * p.face},${p.scale * L.height})`}>
      <ellipse cx={0} cy={2} rx={150} ry={20} fill="rgba(0,0,0,0.35)" />
      <g transform={`rotate(${p.lean}, 0, -430)`}>
        {L.backpack && <path d="M-80,-760 C-120,-740 -128,-560 -100,-470 L100,-470 C128,-560 120,-740 80,-760 Z" fill="#4b5563" {...st()} />}
        {L.legs !== 'saree' && <>
          <g transform={`translate(${sx(-44)},-430)`}><Leg l={p.legL} L={L} side={-1} /></g>
          <g transform={`translate(${sx(44)},-430)`}><Leg l={p.legR} L={L} side={1} /></g>
        </>}
        {L.legs === 'saree' && <path d={`M${sx(-110)},-450 C${sx(-140)},-260 ${sx(-150) + p.hairWave * 10},-80 ${sx(-160)},0 L${sx(-110)},-24 L${sx(-70)},6 L${sx(-20)},-20 L${sx(30)},8 L${sx(80)},-18 L${sx(120)},6 L${sx(160)},-4 C${sx(150)},-80 ${sx(140)},-260 ${sx(110)},-450 Z`} fill={L.pant} {...st()} />}
        {L.legs === 'saree' && <path d={`M${sx(-60)},-420 Q${sx(-70)},-200 ${sx(-90)},-20 M${sx(30)},-420 Q${sx(40)},-200 ${sx(50)},-10`} stroke={L.pantDk} strokeWidth={10} fill="none" />}
        <g transform={`translate(0,-430) scale(${1 + (br - 1) * 0.4},${br}) translate(0,430)`}>
          {L.hair === 'kesar' && <g transform={`translate(0,${-776 + p.headDip}) rotate(${p.headRot}) scale(${L.headScale})`}><HairBack L={L} p={p} /></g>}
          <g transform={`translate(${sx(-86)},-748)`}><Arm a={p.armL} L={L} p={p} parentRot={p.lean} /></g>
          {L.torso(w, br)}
          <g transform={`translate(0,${-776 + p.headDip}) rotate(${p.headRot}) scale(${L.headScale})`}>
            <Head p={p} L={L} uid={uid} />
          </g>
          <g transform={`translate(${sx(86)},-748)`}><Arm a={p.armR} L={L} p={p} parentRot={p.lean} /></g>
        </g>
      </g>
    </g>
  );
};
