# Lay the voice lines on a timeline, add ghost-voice FX, and compute per-frame mouth envelopes.
# Writes: remotion/src/timeline.json and work/voice.wav (44.1 kHz mono float)
import json, subprocess, numpy as np, os
SR, FPS = 44100, 30
A = 'assets/'
os.makedirs('work', exist_ok=True)
L = json.load(open(A + 'audio/lines.json'))

FX = {
    'KESAR': 'asetrate=44100*0.93,aresample=44100,aecho=0.8:0.8:70|190:0.4|0.25,highpass=f=180,volume=1.6',
    'KESAR_AS_KABIR': 'asetrate=44100*0.96,aresample=44100,aecho=0.8:0.75:90|240:0.35|0.2,volume=1.2',
}
# extra silence (seconds) AFTER a given scene / BEFORE a given scene, for dramatic beats
SCENE_IN = {'s01_coldopen': 2.5, 's02_title': 1.5, 's03_bus': 1.5, 's06_flashback': 1.2, 's11_baoli_top': 1.0,
            's13_water': 1.0, 's14_camera': 0.6, 's16_hand': 0.4, 's20_photo': 1.0, 's21_city': 1.5, 's22_outro': 1.0}
SCENE_OUT = {'s01_coldopen': 3.0, 's02_title': 2.5, 's08_warning': 1.5, 's13_water': 1.0, 's17_rising': 1.5,
             's18_kaka_top': 1.5, 's19_dawn': 2.0, 's20_photo': 2.0, 's21_city': 3.0, 's22_outro': 3.0}
GAP = {'N': 0.45}  # default gap between lines

def load(path, fx=None):
    cmd = ['ffmpeg', '-v', 'error', '-i', path]
    af = 'aresample=44100' + (',' + fx if fx else '')
    cmd += ['-af', af, '-ac', '1', '-f', 'f32le', '-']
    return np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32)

clips = []
for l in L:
    a = load(A + l['file'], FX.get(l['speaker']))
    # trim trailing silence edge-tts adds
    nz = np.where(np.abs(a) > 0.004)[0]
    end = min(len(a), (nz[-1] + int(0.15 * SR)) if len(nz) else len(a))
    clips.append(a[:end])

t = 0.0; scenes = []; cur = None; out_lines = []
for l, a in zip(L, clips):
    if l['scene'] != cur:
        if cur is not None:
            t += SCENE_OUT.get(cur, 0.6)
            scenes[-1]['end'] = t
        cur = l['scene']
        scenes.append({'id': cur, 'start': t})
        t += SCENE_IN.get(cur, 0.5)
    dur = len(a) / SR
    # mouth envelope per video frame (RMS, normalised per line)
    hop = SR // FPS
    env = [float(np.sqrt(np.mean(a[k:k + hop] ** 2))) for k in range(0, len(a), hop)]
    m = max(env) or 1
    env = [round(min(1, (e / m) * 1.25), 2) for e in env]
    out_lines.append({'i': l['i'], 'scene': cur, 'speaker': l['speaker'], 'text': l['text'], 'start': round(t, 3),
                      'dur': round(dur, 3), 'words': [[round(w[0], 3), round(w[1], 3), w[2]] for w in l['words']], 'env': env})
    l['_t'] = t
    t += dur + GAP.get(l['speaker'], 0.4)
t += SCENE_OUT.get(cur, 0.6)
scenes[-1]['end'] = t
total = t

voice = np.zeros(int(total * SR) + SR, np.float32)
for l, a in zip(L, clips):
    s = int(l['_t'] * SR); voice[s:s + len(a)] += a
voice.tofile('work/voice.f32')
json.dump({'fps': FPS, 'total': round(total, 3), 'frames': int(total * FPS) + 1, 'scenes': scenes, 'lines': out_lines},
          open('remotion/src/timeline.json', 'w'), ensure_ascii=False)
print('total min', round(total / 60, 2), 'frames', int(total * FPS))
for s in scenes: print(s['id'], round(s['start'], 1), round(s['end'] - s['start'], 1))
