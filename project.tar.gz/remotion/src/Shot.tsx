import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, interpolate, random} from 'remotion';

// All coordinates are in source-image pixels (1376 x 768).
const W = 1376, H = 768;

type Pt = {x: number; y: number};
type Face = {eyes: (Pt & {w: number; h: number})[]; lid: string; mouth?: Pt & {w: number}; blinks: number[]; talk?: [number, number]};
type Char = {src: string; pivot: Pt; sway: number; swaySpeed: number; breathe: number; face: Face};
export type ShotData = {
  bg: string; chars: Char[]; dur: number;
  push: [number, number]; pan: [number, number];
  lights?: (Pt & {r: number; color: string})[];
  steam?: Pt[]; subtitle?: string;
};

const noise = (seed: string, f: number, speed = 0.15) => {
  const i = Math.floor(f * speed), t = f * speed - i;
  const a = random(seed + i), b = random(seed + (i + 1));
  return a + (b - a) * (t * t * (3 - 2 * t)); // smooth 0..1
};

const Eyelid: React.FC<{e: Pt & {w: number; h: number}; color: string; blinks: number[]}> = ({e, color, blinks}) => {
  const f = useCurrentFrame();
  let close = 0;
  for (const b of blinks) {
    const d = f - b;
    if (d >= 0 && d < 6) close = Math.max(close, d < 3 ? d / 2 : (5 - d) / 2);
  }
  if (close <= 0) return null;
  return <div style={{position: 'absolute', left: e.x - e.w / 2, top: e.y - e.h / 2, width: e.w, height: e.h * Math.min(1, close) + 1,
    background: color, borderRadius: '50% 50% 45% 45%', borderBottom: '2px solid #2a1a12'}} />;
};

const Mouth: React.FC<{m: Pt & {w: number}; talk: [number, number]; seed: string}> = ({m, talk, seed}) => {
  const f = useCurrentFrame();
  if (f < talk[0] || f > talk[1]) return null;
  const open = Math.max(0, noise(seed, f, 0.55) - 0.25) * 1.4; // 0..1, chatter
  return <div style={{position: 'absolute', left: m.x - m.w / 2, top: m.y - 2, width: m.w, height: 3 + open * m.w * 0.45,
    background: '#1a0a08', borderRadius: '40% 40% 50% 50%', boxShadow: 'inset 0 -3px 0 #5a2a22'}} />;
};

const Character: React.FC<{c: Char; idx: number}> = ({c, idx}) => {
  const f = useCurrentFrame();
  const sway = (noise('s' + idx, f, c.swaySpeed) - 0.5) * 2 * c.sway;
  const br = 1 + Math.sin(f / 30 * Math.PI * 0.5 + idx) * c.breathe;
  return (
    <div style={{position: 'absolute', inset: 0, transformOrigin: `${c.pivot.x}px ${c.pivot.y}px`,
      transform: `rotate(${sway}deg) scale(${1 + (br - 1) * 0.3}, ${br})`}}>
      <Img src={staticFile(c.src)} style={{position: 'absolute', width: W, height: H}} />
      {c.face.eyes.map((e, i) => <Eyelid key={i} e={e} color={c.face.lid} blinks={c.face.blinks} />)}
      {c.face.mouth && c.face.talk && <Mouth m={c.face.mouth} talk={c.face.talk} seed={'m' + idx} />}
    </div>
  );
};

const Steam: React.FC<{p: Pt; seed: string}> = ({p, seed}) => {
  const f = useCurrentFrame();
  return <>{Array.from({length: 14}).map((_, i) => {
    const life = 70, t = ((f + i * (life / 14)) % life) / life;
    const x = p.x + Math.sin(t * 6 + random(seed + i) * 6) * 14 * t + (random(seed + 'x' + i) - 0.5) * 8;
    const y = p.y - t * 150;
    const s = 10 + t * 40;
    return <div key={i} style={{position: 'absolute', left: x - s / 2, top: y - s / 2, width: s, height: s, borderRadius: '50%',
      background: 'rgba(235,235,235,0.9)', opacity: Math.sin(t * Math.PI) * 0.22, filter: 'blur(8px)'}} />;
  })}</>;
};

const Dust: React.FC = () => {
  const f = useCurrentFrame();
  return <>{Array.from({length: 40}).map((_, i) => {
    const x = (random('dx' + i) * W + f * (0.2 + random('dv' + i) * 0.5)) % W;
    const y = random('dy' + i) * H + Math.sin(f / 40 + i) * 12;
    const s = 1.5 + random('ds' + i) * 2.5;
    return <div key={i} style={{position: 'absolute', left: x, top: y, width: s, height: s, borderRadius: '50%',
      background: '#ffe9c0', opacity: 0.25 + 0.35 * noise('do' + i, f, 0.1)}} />;
  })}</>;
};

export const Shot: React.FC<{d: ShotData}> = ({d}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [0, d.dur], [0, 1], {extrapolateRight: 'clamp'});
  const zoom = d.push[0] + (d.push[1] - d.push[0]) * p;
  const pan = d.pan[0] + (d.pan[1] - d.pan[0]) * p;
  const cover = 1080 / H; // fill 1920x1080
  const layer = (depth: number): React.CSSProperties => ({
    position: 'absolute', left: 0, top: 0, width: W, height: H, transformOrigin: '50% 50%',
    transform: `translate(${pan * depth}px, 0) scale(${1 + (zoom - 1) * depth})`,
  });
  return (
    <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: (1920 - W * cover) / 2, top: 0, width: W, height: H, transform: `scale(${cover})`, transformOrigin: '0 0'}}>
        <div style={layer(0.75)}><Img src={staticFile(d.bg)} style={{width: W, height: H}} /></div>
        <div style={layer(1)}>
          {(d.steam || []).map((s, i) => <Steam key={i} p={s} seed={'st' + i} />)}
          {d.chars.map((c, i) => <Character key={i} c={c} idx={i} />)}
          {(d.lights || []).map((l, i) => {
            const fl = 0.75 + 0.25 * noise('fl' + i, f, 0.6) + (random('spark' + Math.floor(f / 2)) > 0.93 ? -0.25 : 0);
            return <div key={i} style={{position: 'absolute', left: l.x - l.r, top: l.y - l.r, width: l.r * 2, height: l.r * 2, borderRadius: '50%',
              background: `radial-gradient(circle, ${l.color} 0%, rgba(0,0,0,0) 65%)`, opacity: fl, mixBlendMode: 'screen'}} />;
          })}
          <Dust />
        </div>
      </div>
      {/* vignette + grain */}
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,0.75) 100%)'}} />
      <AbsoluteFill style={{opacity: 0.08, mixBlendMode: 'overlay'}}>
        <svg width="1920" height="1080"><filter id="g"><feTurbulence type="fractalNoise" baseFrequency="0.9" seed={f % 20} /></filter>
          <rect width="1920" height="1080" filter="url(#g)" /></svg>
      </AbsoluteFill>
      {d.subtitle && <div style={{position: 'absolute', bottom: 60, width: '100%', textAlign: 'center', fontFamily: 'Noto Sans Devanagari, sans-serif',
        fontSize: 52, fontWeight: 700, color: '#fff', textShadow: '0 0 8px #000, 0 3px 4px #000', padding: '0 160px', boxSizing: 'border-box'}}>{d.subtitle}</div>}
    </AbsoluteFill>
  );
};
