import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Person, basePose, Pose} from '../puppet/Person';
import {Actor, Ctx, BG, Vignette, Grain, Subtitle, autoBlink, noise, kf} from './kit';

export type Cam = {x: number; y: number; z: number};
export type Shot = {from: number; cam: Cam | 'wide' | {on: string; z?: number; dy?: number}};

// full pose for an actor at frame f: defaults + idle life + lip-sync
export const livePose = (a: Actor, ctx: Ctx, f: number): Pose => {
  const given = Object.fromEntries(Object.entries(a.pose).filter(([, v]) => v !== undefined));
  const m = a.speaker ? ctx.mouth(f, a.speaker) : 0;
  const talking = m > 0.05 ? 1 : 0;
  return basePose({
    breathe: Math.sin(f / 18 + a.uid.length),
    blink: autoBlink(f, a.uid),
    mouth: m,
    headRot: (noise(a.uid + 'h', f, 0.08) - 0.5) * 3 + talking * (noise(a.uid + 't', f, 0.25) - 0.5) * 5,
    hairWave: Math.sin(f / 15),
    flame: noise('fl' + a.uid, f, 0.7),
    ...given,
  });
};

export const headPos = (p: Pose, a: Actor) => ({x: p.x, y: p.y + p.bob + -935 * p.scale * a.L.height});

const camTransform = (c: Cam) => {
  const z = Math.max(1, c.z);
  const cx = Math.min(1920 - 960 / z, Math.max(960 / z, c.x));
  const cy = Math.min(1080 - 540 / z, Math.max(540 / z, c.y));
  return `translate(${960 - cx * z}px, ${540 - cy * z}px) scale(${z})`;
};

export const Stage: React.FC<{
  ctx: Ctx; f: number; bg?: string; grade?: string; actors: Actor[]; shots?: Shot[]; auto?: boolean;
  under?: React.ReactNode; over?: React.ReactNode; screen?: React.ReactNode; filter?: string; shake?: number; noSubs?: boolean; drift?: number;
}> = ({ctx, f, bg, grade, actors, shots, auto = true, under, over, screen, filter, shake = 0, noSubs, drift = 0.035}) => {
  const poses = actors.map((a) => livePose(a, ctx, f));
  // choose the active shot
  let shot: Shot | undefined;
  const list: Shot[] = shots ? [...shots] : [];
  if (auto && !shots) {
    ctx.lines.forEach((l, k) => {
      const who = actors.findIndex((a) => a.speaker === l.speaker);
      list.push({from: ctx.at(k), cam: who >= 0 ? {on: actors[who].uid} : 'wide'});
    });
  }
  for (const s of list) if (f >= s.from) shot = s;
  let cam: Cam = {x: 960, y: 540, z: 1};
  const since = shot ? f - shot.from : f;
  if (shot && shot.cam !== 'wide') {
    if ('on' in shot.cam) {
      const i = actors.findIndex((a) => a.uid === (shot!.cam as {on: string}).on);
      if (i >= 0) {
        const h = headPos(poses[i], actors[i]);
        const z = shot.cam.z ?? 1.9;
        cam = {x: h.x, y: h.y + (shot.cam.dy ?? 70), z};
      }
    } else cam = shot.cam as Cam;
  }
  cam = {...cam, z: cam.z * (1 + drift * Math.min(1, since / 240))};
  const sx = shake ? (noise('shx', f, 1.3) - 0.5) * shake : 0;
  const sy = shake ? (noise('shy', f, 1.3) - 0.5) * shake : 0;
  return (
    <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
      <AbsoluteFill style={{transform: `translate(${sx}px,${sy}px) ${camTransform(cam)}`, transformOrigin: '0 0', filter}}>
        {bg && <BG name={bg} grade={grade} />}
        {under}
        <svg width={1920} height={1080} style={{position: 'absolute', overflow: 'visible'}}>
          {actors.map((a, i) => <Person key={a.uid} uid={a.uid} L={a.L} p={poses[i]} />)}
        </svg>
        {over}
      </AbsoluteFill>
      {screen}
      <Vignette />
      <Grain f={f} />
      
    </AbsoluteFill>
  );
};

export const fadeEdges = (f: number, total: number, inF = 12, outF = 12) =>
  Math.max(kf(f, [[0, 1], [inF, 0]], false), kf(f, [[total - outF, 0], [total, 1]], false));
