import React from 'react';
import {Composition} from 'remotion';
import {Shot, ShotData} from './Shot';
import {KakaScene} from './KakaScene';
import {CastPreview} from './puppet/CastPreview';
import {Episode, EPISODE_FRAMES} from './ep/Episode';

const test: ShotData = {
  bg: 's03a/bg.png', dur: 240, push: [1.0, 1.09], pan: [0, -30],
  chars: [
    {src: 's03a/kaka.png', pivot: {x: 431, y: 762}, sway: 0.9, swaySpeed: 0.05, breathe: 0.006,
      face: {lid: '#6b3a24', blinks: [45, 150, 215], talk: [20, 200], mouth: {x: 541, y: 253, w: 26},
        eyes: [{x: 526, y: 181, w: 24, h: 12}, {x: 569, y: 190, w: 22, h: 11}]}},
    {src: 's03a/arjun.png', pivot: {x: 991, y: 661}, sway: 0.5, swaySpeed: 0.04, breathe: 0.005,
      face: {lid: '#b07050', blinks: [80, 190], eyes: [{x: 916, y: 205, w: 20, h: 10}]}},
  ],
  lights: [{x: 670, y: 450, r: 150, color: 'rgba(255,170,60,0.85)'}],
  steam: [{x: 312, y: 462}, {x: 835, y: 372}],
  subtitle: 'बेटा... आज अमावस है। वहाँ मत जाना।',
};

export const Root: React.FC = () => (
  <>
    <Composition id="Test" component={Shot} defaultProps={{d: test}} durationInFrames={240} fps={30} width={1920} height={1080} />
    <Composition id="KakaTest" component={KakaScene} defaultProps={{bg: 'bg/village_dusk.png'}} durationInFrames={300} fps={30} width={1920} height={1080} />
    <Composition id="Cast" component={CastPreview} durationInFrames={120} fps={30} width={1920} height={1080} />
    <Composition id="Episode" component={Episode} durationInFrames={EPISODE_FRAMES} fps={30} width={1920} height={1080} />
  </>
);
