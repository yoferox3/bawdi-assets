// Bundle once, render many stills: node stills.mjs out_dir frame1 frame2 ...
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path';
const [outDir, ...frames] = process.argv.slice(2);
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const comp = await selectComposition({serveUrl, id: 'Episode', browserExecutable: '/usr/bin/google-chrome'});
for (const f of frames) {
  await renderStill({serveUrl, composition: comp, frame: Number(f), output: `${outDir}/f${f}.png`, browserExecutable: '/usr/bin/google-chrome', scale: 0.5});
  console.log('still', f);
}
