import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';
import {Person, Pose, INK, Look} from '../puppet/Person';
import {noise} from './kit';

const st = (w = 6) => ({stroke: INK, strokeWidth: w, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const});

// A photo: a background + puppets frozen in a frame, with a harsh camera-flash look.
export const PhotoContent: React.FC<{bg: string; people: {L: Look; p: Pose; uid: string}[]; w: number; h: number; flash?: boolean}> = ({bg, people, w, h, flash = true}) => (
  <div style={{position: 'relative', width: w, height: h, overflow: 'hidden', background: '#000'}}>
    <div style={{position: 'absolute', width: 1920, height: 1080, transform: `scale(${w / 1920})`, transformOrigin: '0 0',
      filter: flash ? 'brightness(1.25) contrast(1.35) saturate(0.55)' : undefined}}>
      <Img src={staticFile(`bg/${bg}.jpg`)} style={{width: 1920, height: 1080, objectFit: 'cover'}} />
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>{people.map((x) => <Person key={x.uid} uid={x.uid} L={x.L} p={x.p} />)}</svg>
      {flash && <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 45%, rgba(255,255,255,0.35), rgba(0,0,0,0.55) 75%)'}} />}
    </div>
  </div>
);

// Full-screen camera LCD showing a photo
export const CameraLCD: React.FC<{f: number; children: React.ReactNode; label?: string; shake?: number}> = ({f, children, label = 'IMG_0666.JPG', shake = 0}) => {
  const sx = (noise('lcdx', f, 1.1) - 0.5) * shake, sy = (noise('lcdy', f, 1.1) - 0.5) * shake;
  return (
    <AbsoluteFill style={{background: '#0c0d10', transform: `translate(${sx}px,${sy}px)`}}>
      <div style={{position: 'absolute', left: 150, top: 80, width: 1620, height: 920, borderRadius: 40, background: '#1d1f24', border: '8px solid #33363d'}} />
      <div style={{position: 'absolute', left: 230, top: 140, width: 1460, height: 800, overflow: 'hidden', borderRadius: 8}}>
        {children}
        <div style={{position: 'absolute', left: 24, top: 16, color: '#fff', fontFamily: 'monospace', fontSize: 30, textShadow: '0 0 4px #000'}}>{label}</div>
        <div style={{position: 'absolute', right: 24, top: 16, color: '#fff', fontFamily: 'monospace', fontSize: 30, textShadow: '0 0 4px #000'}}>▮▮▯ 23:14</div>
        <div style={{position: 'absolute', inset: 0, background: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.08) 0 2px, transparent 2px 4px)'}} />
      </div>
    </AbsoluteFill>
  );
};

// Garlanded framed portrait of Kaka on a wall
export const Portrait: React.FC<{x: number; y: number; w: number; L: Look; p: Pose; f: number}> = ({x, y, w, L, p}) => {
  const h = w * 1.25;
  return (
    <div style={{position: 'absolute', left: x - w / 2, top: y - h / 2, width: w, height: h}}>
      <div style={{position: 'absolute', inset: 0, background: '#5a3b1e', border: '6px solid #2a1a0c', boxShadow: '0 10px 20px rgba(0,0,0,0.5)'}} />
      <div style={{position: 'absolute', left: w * 0.1, top: w * 0.1, width: w * 0.8, height: h - w * 0.2, overflow: 'hidden', background: '#c9b48a',
        filter: 'sepia(0.6) contrast(1.05)'}}>
        <svg width={w * 0.8} height={h - w * 0.2} viewBox="-260 -1300 520 650"><Person uid="portrait" L={L} p={{...p, x: 0, y: 0, scale: 1}} /></svg>
      </div>
      <svg width={w * 1.2} height={h} style={{position: 'absolute', left: -w * 0.1, top: -w * 0.05, overflow: 'visible'}}>
        {Array.from({length: 26}).map((_, i) => {
          const t = i / 25, gx = t * w * 1.2, gy = Math.sin(t * Math.PI) * h * 1.0;
          return <circle key={i} cx={gx} cy={gy} r={w * 0.05} fill={i % 3 === 0 ? '#e9a21b' : '#f2c230'} stroke="#8a5a0c" strokeWidth={2} />;
        })}
        <path d={`M${w * 0.6},${-w * 0.08} L${w * 0.6},${-w * 0.2}`} stroke="#222" strokeWidth={3} />
      </svg>
    </div>
  );
};

// Blanket wrapped around a puppet (drawn in the puppet's own coordinates)
export const Blanket: React.FC<{p: Pose; h: number}> = ({p, h}) => (
  <g transform={`translate(${p.x + (p.shake ? Math.sin(p.shake * 9.7) * 3 : 0)},${p.y}) scale(${p.scale * h})`}>
    <path d="M-150,-760 C-200,-600 -190,-200 -170,0 L170,0 C190,-200 200,-600 150,-760 C80,-800 -80,-800 -150,-760 Z" fill="#5b6b8c" {...st()} />
    <path d="M-120,-700 L-100,-40 M-40,-740 L-30,-20 M50,-740 L40,-20 M120,-700 L100,-40" stroke="#4a5875" strokeWidth={10} />
    <path d="M-160,-560 Q0,-520 160,-560 M-170,-300 Q0,-260 170,-300" stroke="#c9a441" strokeWidth={8} fill="none" />
  </g>
);

// Pale ghost forearm + claw reaching to (x,y) from angle a (degrees, 0 = from the left)
export const GhostHand: React.FC<{x: number; y: number; a: number; len: number; f: number}> = ({x, y, a, len, f}) => (
  <svg width={1920} height={1080} style={{position: 'absolute', overflow: 'visible'}}>
    <g transform={`translate(${x},${y}) rotate(${a})`}>
      <path d={`M${-len},-26 L-30,-18 L-30,18 L${-len},26 Z`} fill="#b9c4c6" {...st()} />
      <path d={`M${-len + 40},-28 L${-len + 40},28`} stroke="#a3121d" strokeWidth={16} />
      <path d="M-34,-24 C0,-30 20,-20 26,-6 L70,-10 L76,-2 L30,4 L74,10 L76,18 L28,16 L64,30 L60,38 L22,26 C10,34 -20,30 -34,22 Z" fill="#b9c4c6" {...st(5)} />
      <path d="M70,-10 L84,-8 M74,10 L88,12 M64,30 L76,36" stroke="#22262a" strokeWidth={5} />
      {[0, 1, 2].map((i) => {
        const t = ((f + i * 17) % 45) / 45;
        return <ellipse key={i} cx={-60 - i * 50} cy={30 + t * 120} rx={4} ry={8} fill="rgba(170,200,230,0.9)" opacity={1 - t} />;
      })}
    </g>
  </svg>
);

// Accusing pointing hands entering from the frame edges (flashback)
export const Accusers: React.FC<{f: number; on: number}> = ({f, on}) => {
  if (on <= 0) return null;
  const hand = (x: number, y: number, a: number, i: number) => (
    <g key={i} transform={`translate(${x + Math.sin(f / 7 + i) * 8},${y}) rotate(${a}) scale(${on})`}>
      <path d="M-500,-34 L-40,-30 L-40,30 L-500,34 Z" fill="#7a4a2e" {...st()} />
      <path d="M-50,-36 C-10,-40 20,-30 24,-14 L110,-16 Q122,-8 110,0 L24,2 C26,20 10,34 -50,34 Z" fill="#9a6440" {...st(5)} />
    </g>
  );
  return <svg width={1920} height={1080} style={{position: 'absolute', overflow: 'visible'}}>
    {hand(0, 380, 8, 0)}{hand(0, 640, -6, 1)}{hand(1920, 420, 172, 2)}{hand(1920, 700, 186, 3)}
  </svg>;
};

export const Tears: React.FC<{x: number; y: number; f: number}> = ({x, y, f}) => (
  <>{[0, 1].map((i) => {
    const t = ((f + i * 20) % 40) / 40;
    return <div key={i} style={{position: 'absolute', left: x + (i ? 52 : 0), top: y + t * 70, width: 9, height: 16, borderRadius: '50%', background: 'rgba(150,200,255,0.9)', opacity: 1 - t}} />;
  })}</>
);

// Water surface that hides everything under it (for Kesar drowning)
export const WaterSurface: React.FC<{y: number; f: number}> = ({y, f}) => (
  <svg width={1920} height={1080} style={{position: 'absolute'}}>
    <path d={`M0,${y} ${Array.from({length: 33}).map((_, i) => `L${i * 60},${y + Math.sin(f / 5 + i * 0.9) * 8}`).join(' ')} L1920,1080 L0,1080 Z`} fill="rgba(25,30,30,0.96)" stroke="rgba(200,190,160,0.7)" strokeWidth={4} />
  </svg>
);
