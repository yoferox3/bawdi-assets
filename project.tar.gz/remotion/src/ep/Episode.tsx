import React from 'react';
import {Sequence, useCurrentFrame} from 'remotion';
import TL from '../timeline.json';
import {SCENES} from './scenes';
import {makeCtx, FPS} from './kit';

const SceneView: React.FC<{id: string}> = ({id}) => {
  const f = useCurrentFrame();
  const ctx = React.useMemo(() => makeCtx(id), [id]);
  return SCENES[id](f, ctx);
};

export const EPISODE_FRAMES = Math.round(TL.scenes[TL.scenes.length - 1].end * FPS);

export const Episode: React.FC = () => (
  <>
    {TL.scenes.map((s) => {
      const from = Math.round(s.start * FPS), to = Math.round(s.end * FPS);
      return <Sequence key={s.id} from={from} durationInFrames={to - from}><SceneView id={s.id} /></Sequence>;
    })}
  </>
);
