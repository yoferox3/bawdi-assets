import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Person, basePose} from './Person';
import {KAKA, ARJUN, KABIR, KESAR} from './cast';
import {blinkAt, talkOpen} from '../rig';

// Line-up of the cast for approval: idle breathing, blinks, a little talking, a walk cycle for Arjun.
export const CastPreview: React.FC = () => {
  const f = useCurrentFrame();
  const walk = (ph: number) => ({
    legL: {hip: Math.sin(ph) * 22, knee: Math.max(0, -Math.sin(ph)) * 38},
    legR: {hip: -Math.sin(ph) * 22, knee: Math.max(0, Math.sin(ph)) * 38},
    bob: -Math.abs(Math.cos(ph)) * 10,
  });
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#3b2a4a, #1c1420)'}}>
      <svg width={1920} height={1080}>
        <rect x={0} y={1000} width={1920} height={80} fill="#2a2020" />
        <Person uid="ka" L={KAKA} p={basePose({x: 260, y: 1010, scale: 0.72, breathe: Math.sin(f / 18), blink: blinkAt(f, [20, 90]),
          mouth: talkOpen(f, [[10, 60]]), brow: -0.5, armR: {sh: -95, el: -55, hand: 'fist', prop: 'lantern'}, flame: 0.6, swing: Math.sin(f / 10) * 6})} />
        <Person uid="ar" L={ARJUN} p={basePose({x: 720, y: 1010, scale: 0.72, ...walk(f / 5), blink: blinkAt(f, [40]), smile: 0.8,
          armL: {sh: 10 - Math.sin(f / 5) * 14, el: 15, hand: 'open'}, armR: {sh: -10 - Math.sin(f / 5) * 14, el: -25, hand: 'fist', prop: 'torch'}, torchOn: 0})} />
        <Person uid="kb" L={KABIR} p={basePose({x: 1170, y: 1010, scale: 0.72, breathe: Math.sin(f / 14), blink: blinkAt(f, [30, 75]), fear: 0.8,
          shake: f, mouth: talkOpen(f, [[50, 100]]), armL: {sh: 12, el: 20, hand: 'open'}, armR: {sh: -25, el: -95, hand: 'fist', prop: 'phone'}})} />
        <Person uid="ke" L={KESAR} p={basePose({x: 1660, y: 990 + Math.sin(f / 20) * 10, scale: 0.72, hairWave: Math.sin(f / 15), blink: 0,
          armL: {sh: 40 + Math.sin(f / 12) * 8, el: 50, hand: 'claw'}, armR: {sh: -20, el: -20, hand: 'claw'}, headRot: -8})} />
      </svg>
    </AbsoluteFill>
  );
};
