#!/bin/bash
# Render the episode in 4 chunks, then join them with the soundtrack (work/mix.wav).
cd "$(dirname "$0")"
TOTAL=$(node -e "const t=require('./src/timeline.json');console.log(Math.round(t.scenes[t.scenes.length-1].end*30))")
STEP=$(( (TOTAL + 3) / 4 ))
mkdir -p ../out
for i in 0 1 2 3; do
  [ -f ../out/part_$i.mp4 ] && { echo "PART $i exists"; continue; }
  S=$(( i * STEP )); E=$(( (i + 1) * STEP - 1 )); [ $E -ge $TOTAL ] && E=$(( TOTAL - 1 ))
  npx remotion render src/index.ts Episode ../out/part_$i.tmp.mp4 --frames=$S-$E --concurrency=2 --crf=20 > ../out/part_$i.log 2>&1 || { echo "PART $i FAILED"; exit 1; }
  mv ../out/part_$i.tmp.mp4 ../out/part_$i.mp4; echo "PART $i DONE $(date +%T)"
done
cd ../out && printf "file 'part_0.mp4'\nfile 'part_1.mp4'\nfile 'part_2.mp4'\nfile 'part_3.mp4'\n" > parts.txt
ffmpeg -v error -y -f concat -safe 0 -i parts.txt -i ../work/mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart bawdi_ki_pukaar_v2.mp4 && echo ALL_DONE
