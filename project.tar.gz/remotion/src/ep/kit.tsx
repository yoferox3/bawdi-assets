import React from 'react';
import {AbsoluteFill, Img, staticFile, random, interpolate, Easing} from 'remotion';
import TL from '../timeline.json';
import {Pose, Look} from '../puppet/Person';

export const FPS = 30;
export type Line = (typeof TL.lines)[number];
export const sceneOf = (id: string) => TL.scenes.find((s) => s.id === id)!;
export const sceneFrames = (id: string) => {
  const s = sceneOf(id);
  return Math.round((s.end - s.start) * FPS);
};

// Context for one scene: local line timing + speech envelopes.
export const makeCtx = (id: string) => {
  const sc = sceneOf(id);
  const lines = TL.lines.filter((l) => l.scene === id);
  const at = (k: number) => Math.round((lines[k].start - sc.start) * FPS);       // frame a line starts
  const endOf = (k: number) => Math.round((lines[k].start + lines[k].dur - sc.start) * FPS);
  const mouth = (f: number, speaker: string) => {
    for (const l of lines) {
      if (l.speaker !== speaker) continue;
      const k = f - Math.round((l.start - sc.start) * FPS);
      if (k >= 0 && k < l.env.length) return l.env[k];
    }
    return 0;
  };
  const current = (f: number) => lines.find((l) => {
    const s = Math.round((l.start - sc.start) * FPS);
    return f >= s && f < s + Math.round(l.dur * FPS) + 6;
  });
  return {id, sc, lines, at, endOf, mouth, current, total: sceneFrames(id)};
};
export type Ctx = ReturnType<typeof makeCtx>;

// ---------- motion helpers ----------
export const kf = (f: number, keys: [number, number][], ease = true) => {
  if (keys.length === 1) return keys[0][1];
  return interpolate(f, keys.map((k) => k[0]), keys.map((k) => k[1]), {
    easing: ease ? Easing.inOut(Easing.cubic) : undefined, extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
};
export const noise = (seed: string, f: number, speed = 0.15) => {
  const i = Math.floor(f * speed), t = f * speed - i;
  const a = random(seed + i), b = random(seed + (i + 1));
  return a + (b - a) * (t * t * (3 - 2 * t));
};
// natural blinks every 2.5-5 s
export const autoBlink = (f: number, seed: string) => {
  let t = Math.floor(random(seed) * 60), c = 0;
  while (t <= f) {
    const d = f - t;
    if (d < 7) c = d < 3 ? d / 2.5 : Math.max(0, (6 - d) / 3);
    t += 75 + Math.floor(random(seed + t) * 75);
  }
  return Math.min(1, c);
};
// walk/run cycle: returns leg+arm swing and bob for a phase (radians)
export const gait = (ph: number, amt = 1, run = false) => {
  const a = run ? 34 : 22, k = run ? 60 : 38;
  return {
    legL: {hip: Math.sin(ph) * a * amt, knee: Math.max(0, -Math.sin(ph)) * k * amt},
    legR: {hip: -Math.sin(ph) * a * amt, knee: Math.max(0, Math.sin(ph)) * k * amt},
    bob: -Math.abs(Math.cos(ph)) * (run ? 18 : 10) * amt,
    lean: run ? 8 * amt : 0,
    armSwing: Math.sin(ph) * (run ? 40 : 16) * amt,
  };
};
// move from x0 to x1 between frames, with a gait while moving
export const travel = (f: number, f0: number, f1: number, x0: number, x1: number, run = false) => {
  const p = Math.min(1, Math.max(0, (f - f0) / Math.max(1, f1 - f0)));
  const moving = f > f0 && f < f1 ? 1 : 0;
  const dist = Math.abs(x1 - x0) * p;
  const g = gait(dist / (run ? 55 : 38), moving, run);
  return {x: x0 + (x1 - x0) * p, dir: (x1 >= x0 ? 1 : -1) as 1 | -1, moving, ...g};
};

// ---------- actors ----------
export type Actor = {L: Look; uid: string; pose: Partial<Pose>; speaker?: string};

// ---------- backgrounds + grades ----------
export const BG: React.FC<{name: string; grade?: string; blur?: number}> = ({name, grade, blur}) => (
  <AbsoluteFill>
    <Img src={staticFile(`bg/${name}.jpg`)} style={{width: '100%', height: '100%', objectFit: 'cover', filter: blur ? `blur(${blur}px)` : undefined}} />
    {grade && <AbsoluteFill style={{background: grade}} />}
  </AbsoluteFill>
);
export const GRADE = {
  night: 'linear-gradient(180deg, rgba(5,15,45,0.35), rgba(0,5,20,0.45))',
  deep: 'linear-gradient(180deg, rgba(0,5,25,0.55), rgba(0,0,10,0.65))',
  dusk: 'linear-gradient(180deg, rgba(60,10,30,0.12), rgba(20,5,20,0.25))',
  day: 'linear-gradient(180deg, rgba(255,220,160,0.05), rgba(0,0,0,0.08))',
  dawn: 'linear-gradient(180deg, rgba(40,70,120,0.25), rgba(10,20,40,0.25))',
};

// ---------- effects ----------
export const Vignette: React.FC<{k?: number}> = ({k = 0.8}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 48%, rgba(0,0,0,0) 45%, rgba(0,0,0,${k}) 100%)`}} />
);
export const Grain: React.FC<{f: number}> = ({f}) => (
  <AbsoluteFill style={{opacity: 0.1, mixBlendMode: 'overlay'}}>
    <Img src={staticFile(`grain${Math.floor(f / 2) % 6}.png`)} style={{width: 1920, height: 1080, imageRendering: 'pixelated'}} />
  </AbsoluteFill>
);
export const Fog: React.FC<{f: number; k?: number; y?: number}> = ({f, k = 0.14, y = 620}) => (
  <>{[0, 1, 2].map((i) => (
    <div key={i} style={{position: 'absolute', left: -700 + ((f * (0.5 + i * 0.3) + i * 800) % 2700), top: y + i * 90, width: 1500, height: 400,
      borderRadius: '50%', background: `radial-gradient(ellipse, rgba(200,210,230,${k}), rgba(0,0,0,0) 70%)`}} />
  ))}</>
);
export const Dust: React.FC<{f: number; color?: string; n?: number}> = ({f, color = '#ffe9c0', n = 40}) => (
  <>{Array.from({length: n}).map((_, i) => {
    const x = (random('dx' + i) * 1920 + f * (0.3 + random('dv' + i) * 0.8)) % 1920;
    const y = random('dy' + i) * 1080 + Math.sin(f / 40 + i) * 14;
    const s = 2 + random('ds' + i) * 3;
    return <div key={i} style={{position: 'absolute', left: x, top: y, width: s, height: s, borderRadius: '50%', background: color, opacity: 0.2 + 0.35 * noise('do' + i, f, 0.1)}} />;
  })}</>
);
export const Glow: React.FC<{x: number; y: number; r: number; f: number; color?: string; k?: number}> = ({x, y, r, f, color = '255,170,70', k = 0.55}) => {
  const fl = 0.75 + 0.25 * noise('gl' + x, f, 0.6);
  return <div style={{position: 'absolute', left: x - r, top: y - r, width: r * 2, height: r * 2, borderRadius: '50%',
    background: `radial-gradient(circle, rgba(${color},${k}) 0%, rgba(${color},${k * 0.3}) 35%, rgba(0,0,0,0) 68%)`, mixBlendMode: 'screen', opacity: fl}} />;
};
export const Flash: React.FC<{f: number; at: number[]}> = ({f, at}) => {
  let o = 0;
  for (const a of at) { const d = f - a; if (d >= 0 && d < 8) o = Math.max(o, 1 - d / 8); }
  return o > 0 ? <AbsoluteFill style={{background: '#fff', opacity: o * 0.85}} /> : null;
};
export const Ripple: React.FC<{f: number; x: number; y: number; from: number; n?: number; w?: number}> = ({f, x, y, from, n = 4, w = 420}) => {
  if (f < from) return null;
  return <svg width={1920} height={1080} style={{position: 'absolute'}}>{Array.from({length: n}).map((_, i) => {
    const t = ((f - from) / 90 - i * 0.25);
    if (t <= 0 || t > 1.4) return null;
    return <ellipse key={i} cx={x} cy={y} rx={t * w} ry={t * w * 0.22} fill="none" stroke="rgba(180,200,230,0.6)" strokeWidth={4 * (1.4 - t)} />;
  })}</svg>;
};
export const Drips: React.FC<{f: number; x: number; y: number; on?: boolean}> = ({f, x, y, on = true}) => !on ? null : (
  <>{Array.from({length: 5}).map((_, i) => {
    const t = ((f + i * 13) % 40) / 40;
    return <div key={i} style={{position: 'absolute', left: x + (random('dr' + i) - 0.5) * 60, top: y + t * 160, width: 6, height: 12, borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
      background: 'rgba(170,200,230,0.85)', opacity: 1 - t}} />;
  })}</>
);
export const WaterRise: React.FC<{f: number; level: number; bottom?: number}> = ({f, level, bottom = 1080}) => (
  <svg width={1920} height={1080} style={{position: 'absolute'}}>
    <path d={`M0,${level} ${Array.from({length: 25}).map((_, i) => `L${i * 80},${level + Math.sin(f / 6 + i) * 10}`).join(' ')} L1920,${level} L1920,${bottom} ${Array.from({length: 25}).map((_, i) => `L${1920 - i * 80},${bottom + Math.sin(f / 5 + i * 1.3) * 12}`).join(' ')} L0,${bottom} Z`}
      fill="rgba(8,18,30,0.92)" stroke="rgba(150,180,210,0.6)" strokeWidth={4} />
  </svg>
);
export const Footprints: React.FC<{pts: [number, number][]; f: number; from: number; every?: number; color?: string}> = ({pts, f, from, every = 8, color = 'rgba(20,30,45,0.75)'}) => (
  <svg width={1920} height={1080} style={{position: 'absolute'}}>{pts.map(([x, y], i) => f >= from + i * every ?
    <ellipse key={i} cx={x} cy={y} rx={16} ry={7} fill={color} transform={`rotate(${i % 2 ? 8 : -8},${x},${y})`} /> : null)}</svg>
);
export const Black: React.FC<{o: number}> = ({o}) => (o > 0 ? <AbsoluteFill style={{background: '#000', opacity: Math.min(1, o)}} /> : null);

// ---------- subtitles ----------
const groups = (l: Line) => {
  const out: {s: number; e: number; t: string}[] = [];
  let cur: string[] = [], s = 0;
  l.words.forEach((w, i) => {
    if (!cur.length) s = w[0] as number;
    cur.push(w[2] as string);
    const last = i === l.words.length - 1;
    if (cur.length >= 7 || last) {
      const e = last ? l.dur : (l.words[i + 1][0] as number);
      out.push({s, e, t: cur.join(' ')}); cur = [];
    }
  });
  return out;
};
export const Subtitle: React.FC<{ctx: Ctx; f: number}> = ({ctx, f}) => {
  const l = ctx.current(f);
  if (!l) return null;
  const tt = (f - Math.round((l.start - ctx.sc.start) * FPS)) / FPS;
  const g = groups(l).find((g, i, a) => tt >= (i === 0 ? -1 : g.s) && tt < (i === a.length - 1 ? 99 : a[i + 1].s));
  if (!g) return null;
  const spoken = l.speaker !== 'N';
  return <div style={{position: 'absolute', bottom: 58, width: '100%', textAlign: 'center', fontFamily: "'Noto Sans Devanagari'", fontSize: 54, fontWeight: 700,
    color: spoken ? '#ffe9a8' : '#fff', textShadow: '0 0 10px #000, 0 3px 4px #000, 0 0 2px #000', padding: '0 180px', boxSizing: 'border-box'}}>{g.t}</div>;
};
